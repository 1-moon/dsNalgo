import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
import cv2, time
from PyQt5.QtCore import QThread, pyqtSignal, Qt
from PyQt5.QtGui import QImage


class Video(QThread): # inherit QThread 
    updateFrame = pyqtSignal(QImage)

    def __init__(self, parent=None):
        super().__init__()
        self.main = parent
        self.running = False

    def run(self):
        while self.running:
            if self.main.isVideoPlay:
                retval, frame = self.main.video.read()  # self.main = WindowClass, video = instance of videoCapture 
                if retval:  # retval = frame is read successfully ? (bool)
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # QImage는 RGB 
                    h, w, c = frame.shape # c = channel 
                    qimage = QImage(frame.data, w, h, w * c, QImage.Format_RGB888)
                    self.updateFrame.emit(qimage)
                    time.sleep(self.main.interval)
                else:
                    self.running = False

    def start(self):     # thread start 
        self.running = True
        super().start()  # super = QThread 

    def stop(self):      # thread stop 
        self.running = False
        self.wait()

from_class = uic.loadUiType("video.ui")[0]
class WindowClass(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.isVideoPlay = False 
        self.btnPlay.hide()
        self.pixmap = QPixmap()

        self.btnOpen.clicked.connect(self.openFile)
        self.btnPlay.clicked.connect(self.clickPlay)
    
    def clickPlay(self):
        if self.isVideoPlay == False:
            self.btnPlay.setText("Pause")
            self.isVideoPlay = True
            self.videoPlayStart()
        else:
            self.btnPlay.setText("Play")
            self.isVideoPlay = False
            self.videoPlayStop()
   
    def videoPlayStart(self):
        if not self.videoThread.isRunning():
            self.videoThread.start()
    
    def videoPlayStop(self):
        self.videoThread.stop()

    def openFile(self):
        file = QFileDialog.getOpenFileName(filter='Media Files (*.mp4 *.avi *.mov *.png *.jpg *.bmp)')
        if file[0]:
            if file[0].lower().endswith(('.mp4', '. avi', '.mov')):
                self.video = cv2.VideoCapture(file[0])
                self.btnPlay.show()
            elif file[0].lower().endswith(('.png', '.jpg', '.bmp')):
                image = cv2.imread(file[0])
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                h, w, c = image.shape
                qimage = QImage(image.data, w, h, w * c, QImage.Format_RGB888)

                self.pixmap = QPixmap.fromImage(qimage)
                self.pixmap = self.pixmap.scaled(self.label.width(), self.label.height(), Qt.KeepAspectRatio)
                self.label.setPixmap(self.pixmap)
        else:
            QMessageBox.information(self, "No File Selected", 
                                    "Please select a video file to play.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = WindowClass()
    myWindow.show()
    sys.exit(app.exec_())