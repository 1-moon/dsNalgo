import sys, os
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
from PyQt5.QtCore import Qt
import urllib.request
from_class = uic.loadUiType("test7.ui")[0]

class WindowClass(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        min = self.spinBox.minimum()
        max = self.spinBox.maximum()
        step = self.spinBox.singleStep()

        self.editMin.setText(str(min))
        self.editMax.setText(str(max))
        self.editStep.setText(str(step))

        self.slider.setRange(min, max)
        self.slider.setSingleStep(step)

        self.btnApply.clicked.connect(self.apply)
        self.spinBox.valueChanged.connect(self.change)
        self.slider.valueChanged.connect(self.changeSlider)
        self.btnSave.clicked.connect(self.save_img)
        self.btnLoad.clicked.connect(self.load_img)

        url = "https://image.fmkorea.com/files/attach/new2/20220322/494354581/1656842798/4454353958/106eed90b47743e26c0f69cec663b057.png"
        image = urllib.request.urlopen(url).read()
        
        self.pixmap = None
         
  
    def save_img(self):
        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getSaveFileName(self, "Save Image File", "",
                                                "Images (*.png *.jpg *.bmp)", options=options)
        if fileName:
            if not self.pixmap.isNull():
                success = self.pixmap.save(fileName)
                if success:
                    QMessageBox.information(self, "Success", "Image saved successfully.")
                else:
                    QMessageBox.critical(self, "Error", "Failed to save image.")
            else:
                QMessageBox.critical(self, "Error", "Pixmap is null, cannot save image.")


    def load_img(self):
        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getOpenFileName(self, "Open Image File", './',
                                                "Images (*.png *.jpg *.bmp)", options=options)
        if fileName:
            self.pixmap = QPixmap(fileName)
            if not self.pixmap.isNull():
                self.pixmap = self.pixmap.scaled(self.labelPixmap.width(), self.labelPixmap.height(), Qt.KeepAspectRatio)
                self.labelPixmap.setPixmap(self.pixmap)
                self.labelPixmap.resize(self.pixmap.width(), self.pixmap.height())
     
    
    def changeSlider(self):
        actualValue = self.slider.value()
        self.labelValue2.setText(str(actualValue))
        self.spinBox.setValue(actualValue)
        self.updateImageSize(actualValue)

    def change(self):
        actualValue = self.spinBox.value()
        self.labelValue.setText(str(actualValue))
        # self.slider.setValue(actualValue)
        self.updateImageSize(actualValue)

    def apply(self):
        min = self.editMin.text()
        max = self.editMax.text()
        step = self.editStep.text()

        self.spinBox.setRange(int(min), int(max))
        self.spinBox.setSingleStep(int(step))

        self.slider.setRange(int(min), int(max))
        self.slider.setSingleStep(int(step))
    def updateImageSize(self, value):

        new_width = int(self.pixmap.width() * (value/100))
        new_height = int(self.pixmap.height() * (value/100))
        print(f"Scaling to: {new_width} x {new_height}")
        
        scaled_pixmap = self.pixmap.scaled(new_width, new_height, Qt.KeepAspectRatio)
        self.labelPixmap.setPixmap(scaled_pixmap)
        self.labelPixmap.resize(scaled_pixmap.width(), scaled_pixmap.height())



    
if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindows = WindowClass()
    myWindows.show()

    sys.exit(app.exec())
