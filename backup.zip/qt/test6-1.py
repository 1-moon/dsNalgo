import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
import mysql.connector # Import mysql connector

from_class = uic.loadUiType("test6-1.ui")[0]

class WindowClass(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        # sort out headers 
        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.btnSearch.clicked.connect(self.search)

        # db credentials
        self.mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="0000",
            database="edadb"
        )
        self.mycursor = self.mydb.cursor()
        self.load_combo_options(self.cbSex, "SEX")
        self.load_combo_options(self.cbJob, "JOB_TITLE")
        self.load_combo_options(self.cbAgency, "AGENCY")
        
    def load_combo_options(self, combo_box, column_name):
        try:
            query = f"SELECT DISTINCT {column_name} FROM celeb"  # Dynamic query
            self.mycursor.execute(query)
            options = [row[0] for row in self.mycursor.fetchall()]
            combo_box.addItem("All")
            combo_box.addItems(options)
            combo_box.setCurrentText("All")
        except mysql.connector.Error as err:
            print(f"Error loading {column_name} options: {err}")
            QMessageBox.critical(self, "Database Error", str(err))
    def search(self):
        # name = self.editName.text()
        sex = self.cbSex.currentText()
        job = self.cbJob.currentText()
        agency = self.cbAgency.currentText()
        birthdate_start = self.startDate.date().toString("yyyy-MM-dd")
        birthdate_end = self.endDate.date().toString("yyyy-MM-dd")

        query = "SELECT * FROM celeb WHERE 1=1"  # Start with a basic query

        # if name:
        #     query += f" AND NAME LIKE '%{name}%'"

        if sex != "All":  # Check if sex is NOT "All"
            query += f" AND SEX = '{sex}'"

        if job != "All":  # Check if job is NOT "All"
            query += f" AND JOB_TITLE = '{job}'"

        if agency != "All":  # Check if agency is NOT "All"
            query += f" AND AGENCY LIKE '%{agency}%'"

        if birthdate_start and birthdate_end:  # Date range check
            query += f" AND BIRTHDAY BETWEEN '{birthdate_start}' AND '{birthdate_end}'"

        try:
            self.mycursor.execute(query)
            results = self.mycursor.fetchall()

            # Populate tableWidget
            self.tableWidget.setRowCount(0)  # Clear existing rows
            for row in results:
                row_num = self.tableWidget.rowCount()
                self.tableWidget.insertRow(row_num)
                for col_num, col_data in enumerate(row):
                    item = QTableWidgetItem(str(col_data))
                    self.tableWidget.setItem(row_num, col_num, item)

        except mysql.connector.Error as err:
            print(f"Error searching: {err}")
            QMessageBox.critical(self, "Database Error", str(err))  
if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindows = WindowClass()
    myWindows.show()

    sys.exit(app.exec())
