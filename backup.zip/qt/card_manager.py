import sys, serial, struct 
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
from PyQt5.QtCore import * 

# 응답을 받을 Thread 
class Receiver(QThread):
    detected = pyqtSignal(bytes)    # tag인식시 signal 
    recvTotal = pyqtSignal(int)

    def __init__(self, conn, parent=None):
        super(Receiver, self).__init__(parent)
        self.is_running = False
        self.conn = conn 
        print("recv init")

    def run(self):
        print("recv start")
        self.is_running = True
        while (self.is_running == True):
            if self.conn.readable():
                res = self.conn.read_until(b'\n')
                if len(res) >0:
                    res = res[:-2] # 끝에서 2개 요소 제외하고 가져오기 
                    cmd = res[:2].decode() # 처음 두 바이트 추출 
                    if cmd == 'GS' and res[2] == 0:
                        print("recv detected")
                        self.detected.emit(res[3:])
                    elif cmd == 'GT' and res[2] == 0: # res[2]: 0x00
                        print("recvTotal")
                        print(len(res))     # 응답이 오면 signal을 잔액과 함께 날리자 
                        self.recvTotal.emit(int.from_bytes(res[3:7], 'little'))
                    else:
                        print("unknown err")
                        print(cmd)
    def stop(self):
        print("recv stop")
        self.is_running = False


from_class = uic.loadUiType("card_manager.ui")[0]
class WindowClass(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.uid = bytes(4)
        self.conn = \
            serial.Serial(port='/dev/ttyACM0',
                         baudrate=9600, timeout=1)
        # Gui 가 시작할때 thread도 같이 시작 
        self.recv = Receiver(self.conn)
        self.recv.start()
        # signal을 받으면 함수에 연결 
        self.recv.detected.connect(self.detected)
        self.recv.recvTotal.connect(self.recvTotal) 

        # components 
        self.btnReset.clicked.connect(self.reset)
        self.btnCharge.clicked.connect(self.charge)
        self.btnPayment.clicked.connect(self.pay)
        
        self.disable()  # 시작시 disable 
        # GS를 Tag가 인식될때까지 반복해서 요청 
        self.timer = QTimer()
        self.timer.setInterval(3000)
        self.timer.timeout.connect(self.getStatus)
        self.timer.start()

    def send(self, cmd, data=0):
        print("send")
        req_data = struct.pack('<2s4sic', cmd, self.uid, data, b'\n') #b'' : byte Literal
        self.conn.write(req_data) 
        return 
    # send 에 들어갈 명령 함수들~ 
    def getStatus(self):
        print("getStatus")
        self.send(b'GS')
        return 
    def getTotal(self):
        print("getTotal")
        self.send(b'GT')
        return 
    def setTotal(self, total):
        print("setTotal")
        self.send(b'ST', total)
        return 

    # detect card 
    def detected(self, uid):
        print ("detected")
        self.uid = uid  # tag uid 저장하고 
        self.timer.stop()
        # self.enable(0)  # enable ~ 
        # 현재 잔액을 보기 위해서 
        self.getTotal()
        self.btnReset.setDisabled(False)
        return 
    # 잔액 출력, enable 하기 
    def recvTotal(self, total):
        print("recvTotal")
        self.enable(total)
        self.chargeEdit.setText("")
        self.paymentEdit.setText()
        
    def reset(self):
        print("reset~!")
        return 
    def charge(self):
        print("charging ~~~")
        return
    def pay(self):
        print("payment !!!!@!@!@")
        return 
    
    # 카드가 인식이 되고 나서 써야지 
    def enable(self, total):
        self.totalLabel.setText(str(total))
        self.btnPayment.setDisabled(False)
        self.btnCharge.setDisabled(False)
        self.chargeEdit.setDisabled(False)
        self.paymentEdit.setDisabled(False)
    def disable(self):
        self.totalLabel.setText("-")
        self.btnReset.setDisabled(True)
        self.btnCharge.setDisabled(True)
        self.btnPayment.setDisabled(True)
        self.chargeEdit.setDisabled(True)
        self.paymentEdit.setDisabled(True)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindows = WindowClass()
    myWindows.show()

    sys.exit(app.exec_())