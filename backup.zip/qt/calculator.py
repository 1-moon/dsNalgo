import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow

# load .ui file 
from_class = uic.loadUiType("./calculator.ui")[0]

class Calculator(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle("pyqt calculator")
        # connect number signal-slot
        self.btn_0.clicked.connect(lambda: self.number_pressed("0"))
        self.btn_1.clicked.connect(lambda: self.number_pressed("1"))
        self.btn_2.clicked.connect(lambda: self.number_pressed("2"))
        self.btn_3.clicked.connect(lambda: self.number_pressed("3"))
        self.btn_4.clicked.connect(lambda: self.number_pressed("4"))
        self.btn_5.clicked.connect(lambda: self.number_pressed("5"))
        self.btn_6.clicked.connect(lambda: self.number_pressed("6"))
        self.btn_7.clicked.connect(lambda: self.number_pressed("7"))
        self.btn_8.clicked.connect(lambda: self.number_pressed("8"))
        self.btn_9.clicked.connect(lambda: self.number_pressed("9"))
        # connect operator signal-slot
        self.plus.clicked.connect(lambda: self.operator_pressed("+"))
        self.minus.clicked.connect(lambda: self.operator_pressed("-"))
        self.multiply.clicked.connect(lambda: self.operator_pressed("*"))
        self.divide.clicked.connect(lambda: self.operator_pressed("/"))
        self.comma.clicked.connect(lambda: self.operator_pressed("."))
    
        self.equal.clicked.connect(self.calculate_result)
        self.clear.clicked.connect(self.clear_input)
        self.backspace.clicked.connect(self.delete_one)
        self.start_group.clicked.connect(self.add_start_group)
        self.end_group.clicked.connect(self.add_end_group)

        self.input_text = ""  # 현재 입력 중인 숫자
        self.input_list = ""  # 전체 식 저장용
        
    def number_pressed(self, num):
        if isinstance(self.input_list, (int, float)):
            self.input_list = num 
            self.input_text = num 
            self.lineEdit.setText(str(self.input_list)) 
        else :      
            self.input_text += num
            self.input_list += num
            self.lineEdit.setText(self.input_list)  

    def operator_pressed(self, op):
        if self.input_text: # begin with number 
            self.input_list += op
            self.input_text = ""
            self.lineEdit.setText(self.input_list)
        elif (op == '-' or op == '+' or op == '*' or op == '/') and not self.input_list:     # begin with minus 
            self.input_list += op
            self.lineEdit.setText(self.input_list)
        elif isinstance(self.input_list, (int, float)): #begin with str and end with number 
            self.input_list = str(self.input_list) + op
            self.lineEdit.setText(self.input_list)  
        

    def add_start_group(self):
        self.input_list += "("
        self.lineEdit.setText(self.input_list)

    def add_end_group(self):
        self.input_list += ")"
        self.lineEdit.setText(self.input_list)

    def calculate_result(self):
        if self.input_list:
            try:
                result = eval(self.input_list)
                # no remainder ?
                if isinstance(result, float) and result % 1 ==0: 
                    result = int(result) # convert to int 
                
                self.lineEdit.setText(str(result))
                self.input_list = result # save result as number 
                self.input_text = ""
            except Exception:
                self.lineEdit.setText("Error")
                self.input_list = ""
                self.input_text = ""

    def clear_input(self):
        self.input_text = ""
        self.input_list = ""
        self.lineEdit.setText("")
    def delete_one(self):
        if self.input_text:
            operators = ['+', '-', '*', '/']
            if self.input_list[-1] in operators: # last char is operator ? 
                self.input_list = self.input_list[:-2]
                self.input_textt = ""
            else:
                self.input_list = self.input_list[:-1]  # input_list도 함께 제거
                self.input_text = self.input_text[:-1]  # 마지막 문자 제거
                
        self.lineEdit.setText(self.input_list)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Calculator()
    window.show()
    sys.exit(app.exec())
