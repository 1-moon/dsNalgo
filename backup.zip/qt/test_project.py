import socket

HOST = "0.0.0.0"  # 모든 네트워크에서 접근 가능
PORT = 12345

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen(5)

print("서버 실행 중...")

while True:
    client_socket, addr = server_socket.accept()
    print(f"클라이언트 연결됨: {addr}")
    data = client_socket.recv(1024).decode()
    print(f"받은 데이터: {data}")
    client_socket.close()
