import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5 import uic
import cv2, imutils, time 
from PyQt5.QtCore import QThread,pyqtSignal
from PyQt5.QtGui import QImage
class Camera(QThread):
    update = pyqtSignal()   # share it between instances of cam

    def __init__(self, sec=0, parent=None):
        super().__init__()
        self.main = parent 
        self.running = True

    def run(self): 
        count =0
        while self.running == True:
            self.update.emit()
            time.sleep(self.main.interval)
    
    def stop(self):
        self.running = False 

from_class = uic.loadUiType("opencv.ui")[0]
class WindowClass(QMainWindow, from_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.isCameraOn = False
        self.isRecStart = False
        self.interval = 0.05
        self.btnRecord.hide()

        self.pixmap = QPixmap()
        # 읽고 
        self.camera = Camera(self)
        self.camera.daemon = True
        # 쓰고 
        self.record = Camera(self)
        self.record.daemon = True
        
        self.count =0

        self.btnOpen.clicked.connect(self.openFile)
        self.btnCamera.clicked.connect(self.clickCamera)
        self.camera.update.connect(self.updateCamera)
        self.btnRecord.clicked.connect(self.clickRecord)
        self.doubleSpinBox.valueChanged.connect(self.change)
        self.doubleSpinBox.setSingleStep(0.01)
        self.doubleSpinBox.setValue(self.interval)

    def updateRecording(self):
        self.label2.setText(str(self.count))
        self.count +=1
    def change(self, value):
        self.interval = value 

    def clickRecord(self):
        if self.isRecStart == False:
            self.btnRecord.setText("Rec Stop")
            self.isRecStart = True 

            self.recordingStart()
        else:
            self.btnRecord.setText("Rec Start")
            self.isRecStart = False 
            self.recordingStop()
    def recordingStart(self):
        self.record.running = True
        self.record.start()
    def recordingStop(self):
        self.record.running = False
    
    def updateCamera(self):
        # self.label.setText("Camera Running : " + str(self.count))
        # self.count +=1     
        retval, image = self.video.read()
        if retval :
            image =cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            h,w,c = image.shape
            # image conversion into qt format 
            qimage = QImage(image.data, w, h, w*c, QImage.Format_RGB888)

            self.pixmap = self.pixmap.fromImage(qimage)
            self.pixmap = self.pixmap.scaled(self.label.width(),
                                            self.label.height())
            self.label.setPixmap(self.pixmap) 
        self.count +=1
    def clickCamera(self):
        # toggle btn 
        if self.isCameraOn == False:
            self.btnCamera.setText("Camera off")
            self.isCameraOn = True 
            self.btnRecord.show()

            self.cameraStart()
        else:
            self.btnCamera.setText("Camera on")
            self.isCameraOn = False
            self.btnRecord.hide()

            self.cameraStop()

    def cameraStart(self):
        self.camera.running = True
        self.camera.start() # 이거 호출시 QThread 내부적으로 run 호출 
        self.video = cv2.VideoCapture(0)
    def cameraStop(self):
        self.camera.running = False
        self.count = 0
        self.video.release()

    def openFile(self):
        file = QFileDialog.getOpenFileName(filter='Image (*.*)')
        image = cv2.imread(file[0])
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        h, w, c = image.shape
        qimage = QImage(image.data, w, h, w*c, QImage.Format_RGB888)

        self.pixmap = self.pixmap.fromImage(qimage)
        self.pixmap = self.pixmap.scaled(self.label.width(), self.label.height())

        self.label.setPixmap(self.pixmap)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = WindowClass()
    myWindow.show()
    sys.exit(app.exec_())
