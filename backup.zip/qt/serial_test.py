import time, serial 

def connect() :
    conn = serial.Serial(port='/dev/ttyACM0',
                         baudrate=9600, timeout=1)
    
    return conn 

# 입력받은 데이터를 아두이노에 전달하는 함수 
def send(conn):
    while True:
        data = input("Input : ")
        if(data == 'q'):
            break
        
        conn.write(data.encode())
        time.sleep(0.1)

        if (conn.readable()):
            recv = conn.readline().decode().strip('\r\n')
            if (len(recv) > 0):
                print(" recv: " + str(recv))
    return 
if __name__ == "__main__":
    conn = connect()
    # 호출하는 코드 
    send(conn)
    conn.close()