#!/usr/bin/env python3
import sys
import numpy as np
import cv2

src = cv2.imread('./data/이온.jpg', cv2.IMREAD_GRAYSCALE)

if src is None:
    print('Image load failed.')
    sys.exit()


dst1 = cv2.add(src, 100)
dst2 = np.clip(src+100., 0, 255).astype(np.uint8)

cv2.imshow('src', src)
cv2.imshow('dst1', dst1)
cv2.imshow('dst2', dst2)
cv2.waitKey()

src = cv2.imread('이온.jpg')

if src is None:
    print('Image load failed.')
    sys.exit()

dst1 = cv2.add(src, (100, 100,100, 0))
dst2 = np.clip(src + 100., 0, 255).astype(np.uint8)

cv2.imshow('src', src)
cv2.imshow('dst1', dst1)
cv2.imshow('dst2', )
