import cv2
import numpy as np

img = np.ones((512,512,3), np.uint8)

def drawCircle(event, x, y, flags, param):
    pass
cv2.namedWindow(winname='my_first_drawing')
while True:
    cv2.imshow('my_first_drawing', img)

    if cv2.waitKey(10) ==27:
        break
cv2.destoryAllWindows()
