2D textures in OpenGL 

## GL_Texture2D/release()
The allocated 'p_texture' in memory -> deallocate 
=='safe_delete' is for memory allocated with 'New'== (Unlike safe_free with 'malloc') 

## GL_Texture2D/assemble()
This method is being charge of managing input/ouput for plugin framework.  

on_dirty_img; generate image texture  
    1) Image is not allocated in memory, return false  
    2) If pointer to image is invalid, return true; null image skipping for continuous process. 
    3) Get image information including depth and channels
    4) Get OpenGL texture format `imft` using depth and channels of img
    5) Delete the previous image using `safe_delete`
    6) Create OpenGL 2D texture using name, miplevel, width, height, layer, internal format
    7) Generate minimap
	    - set filter(==GL_LINEAR_MIPMAP_LINEAR, GL_LINEAR==)
		(Refer to lecture note GL-texture) 
		**Tri-linear interpolation for minification**; linearly interpolates between two integer levels.
		**Bilinear interpolation for magnification**; smoother visual when textures are scaled up.
					
on_dirty_dynamic;  
        1) Update `enable_loop` of DLL obj(p_rexdll) by `b_dynamic`
        2) Update the instance of `UserFunc` through `set_use_loop()` 
        (if true, the user function executed properly) 

*mbind ? for binding of member functions to the class instance 

- create_control ; create GUI control     
    b_dynamic can be set to True/False, which means user can control over 
    RUNTIME_HiDDEN; one of `attrib_t` enum;  ==the control(UI element) associated with variable `b_dynamic` will not be displayed in the UI while the application is running.== 

##  GL_Texture2D/render

When b_dynamic is active, and both p_texture is not null and the image data is valid, the image is bound to the texture and rendered
