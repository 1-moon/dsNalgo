Color invertion of an image 
	the lighter areas -> dark 
	the dark areas => light 

## TTGL_Invert/metadata; DLL info setup 
- multiple instances 
- update/render => on
- mouse callback => on 


## TTGL_Invert/release; memory deallocation 
- DST;  relevant to texture 
- effect;  relvant to invertion effect 
- FBO;  Frame Buffer Object    

// why release reverse order...?
	It seems to be relying on another... such like ==DST->effect->FBO== 
	In the render method, changing the order of effect and FBO causes malfunction in rendering process. 
## TTGL_Invert/assemble; plugin in/out result   
`DST` ; Destination..? ; It stands for export_data 
`SRC` ; Source..?; It stands for the input data being imported from **GL_Texture2D**

- Register pointer call-back for `pp_SRC`. 
	Once `pp_SRC` is changed, `on_dirty_src` bound to the variable will be called 
- In `on_dirty_src`, 
	Check whether `pp_SRC` is valid or not. 
	Make it into new image texture data(`DST`).
- create_control with `b_invert`
	Generate a tick-box for invertion because of Boolean type 

## TTGL_Invert/initial_update
Called just before beginning the rendering loop 
- Create frame buffer; memory areas that stores fragments/pixels genetated via OpenGL pipeline 
- Create effect 
	get_name; bring the name of plug-in image 
	`STR_TTGL_INVERT_FX`;  the invertion effect 

Once init completed, return true. 

## TTGL_Invert/update 
Being called at every render frame, before rendering of all plugins 
`tprintf()` ..? 
	Customised in rex.h  
	The msgs are displayed when setting Debug mode on the bottom of rex 
1) Add invert control 
2) Right-clicking -> clear/add hot key 
3) Press `.` -> GLFrame toggle down/up 

## TTGL_Invert/render 
Update of all plugins -> render

FBO 
	Depth test -> off
		 All fragements to be rendered regardless of their depth value. 
	Cull Face -> off ; 
		All faces of the owl's image(polygon..?) will be drawn  
	Blend -> off as default
		No need to implement transparency within objects 	 
	Wireframe -> off as default   
		All visible faces of the owl image will be entirly displayed 
	Bind with DST;
		FBO binds with `DST` texture for rendering 
	clear 
		clear FBO 

pp_SRC -> SRC;  allocate to new pointer var 

effect
	-Bind with 'invert' texture   
	-Set `uniform` variables `SRC` and `b_invert` from `TTGL_Invert.fx` 
	-draw/compute effect in rendering process   
		
## TTGL_Invert.fx ; shader file  
The grammar in this file came from OpenGL shading language 
	
interface PSIN
	interface; act like a struct in C++ (#define interface `__STRUCT__`)
	renamed PSIN, contains a `tax` 2D variable     
uniform sampler2D
	uniform; constant data that applies globally to a shader program. 
	sampler2D; type qualifier used to define a texture sampler for 2D textures.   
shader vsQuad
	**Vertex shading** 
	`gl_position`;  sets the final position of the vertex after transformation.    
	`vout.tex`; passes the texture coords to fragment shader.
	- in: position, normal, and texcoord -> point's info
	- out: vec4 position in [[clip space]] 

shader psInvert 
	**Fragment shading** 
	`ivec2 tc`;  screen-to-texture coords  
		`ivec2()` ;  Fragment's coords -> **integer**  
	`pout`;  fetch a texel(`tc`) within a texture(`SRC`)  
	`if(b_invert) pout.rgb = vec3(1) - pout.rgb`
		vec3(1) = vec3 (1.0, 1.0, 1.0) -> rgb 1.0 -> white   
		white - pout(our texture) => invert  
		
program invert 
	setting up invert shading stage 
	`vs(440)`; set verion 440 `vsQuad()`
	`fs(440)`; set version 440 `psInvert()` 
	