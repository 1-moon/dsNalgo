RGB -> gray texture 

## TTGL_rgb2gray/main.cpp 
Resemble code with invert 
- init_update 
	FBO -> init 
	effect -> init and bring rgb2gray.fx
- render 
	`FBO`; same structure with invert 
	`effect`
		bind with rgb2gray 
		Set `uniform` variables `SRC` and `b_invert` from `TTGL_rgb2gray.fx` 
		draw/compute effect in rendering process   
	
## TTGL_rgb2gray.fx 
rgb2gray shader 

`ntsc` ; coefficient value for making gray color 
`shader psrgb2gray`; fragment shading 
	rgb2gray on -> dot product `ntsc` with my texel rgb for gray texture 
		.dot().rrr...? 
			Swizzling in GLSL 
				.r -> first component
				.rrr -> repeat 3 times of first component  i.e. vec3(result, result, result) 