box-blur effect 
Two-pass..?
	apply a blur effect by separating it into two squential passes 
	i.e. one for horizontal, one for vertical pass.  
## TTGL_BoxBlur/release; memory deallocation 
- TMP; seems to stand for **temporary** for holding immediate texture..? 
- DST;  relevant to texture 
- effect;  relvant to invertion effect 
- FBO;  Frame Buffer Object   

## TTGL_BoxBlur/assemble; plugin in/out result 

- export data with `TMP` and `DST` 
- create_control with `b_blur` and `kernel_size`
	Generate a ==tick-box for blur== because of Boolean type 
	Generate a ==spin-box for kernel_size== with default size 16 (min:0 ~ max:64, by step 1 )
		why does it call [[kernel]]...? 


## TTGL_BoxBlur/render 

- blur -> off ? 
	No blurring effect is currently applied -> copying the `SRC` direcly to the `DST` 
	Format between `SRC` and `DST` is different? -> required to define and use a shader with automatic format conversion.  
- blur-> on ? 
	FBO 
		Depth test -> off
			All fragements to be rendered regardless of their depth value. 
		Cull Face -> off ; 
			All faces of the owl's image(polygon..?) will be drawn  
		Blend -> off as default
			No need to implement transparency within objects 	 
		Wireframe -> off as default   
			All visible faces of the owl image will be entirly displayed 
	effect 
		bind with effect shader called `boxblur`  
		set the `kernel_size` uniform variable in the shader program. 
	iterating twice in for-loop 
		1st pass; blur `SRC` into `TMP`  horizontally 
			dst ->TMP
			src -> SRC
			dir -> ivec2(1, 0)
		2nd pass; blur `TMP` into `DST` vertically
			dst -> DST
			src -> TMP
			dir -> ivec2(0,1)
		bind FBO with `dst` texture. 
		set the `src`, `dir` uniform variable in the shader program. 
		draw 

## TTGL_boxblur.fx 
