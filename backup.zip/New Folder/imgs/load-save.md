Image handling for load/save 

- assemble() 
Set the ptr `p_image` with the callback function `on_dirty_image` 
	Whenever `p_image` changes, createa a new texture and store it in `tmp`
`image_name` is also linked with a callback, `on_dirty_image_name`

- update()
 Image saving logic occurs at only first frame. (i.e. not all frames at all)
	 `SRC` -> `tmp` ; extract image data to `tmp` with finest mipmap level 
	 Configure the path of dir for saving image 
		 1) save as `tmp.png` at "caputure" folder  
		 2) save as `tmp.jpg` at plugin dir 
		 3) save as `tmp.jpg` at project data dir 
