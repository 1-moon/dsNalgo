a technique in which each pixel of an image is replaced either by a highlight or a shadow, deponding on light/dark boundaries on the original image 

![[Pasted image 20241028141044.png]]
