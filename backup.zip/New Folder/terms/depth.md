Depth value 
	-> Its distance from the camera 
	smaller depth = closer to the camera 
	