A technique used in 3D rendering to improve performance. 

- Do not draw faces (polygons) of objs that are not visible to the camera 
-