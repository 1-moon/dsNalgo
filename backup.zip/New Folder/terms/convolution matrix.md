Known as a convolution kernel or filter 
	mathmatical construct used in various fields(img processing, vision, and signal processing)

When each pixel in the output image is a function of nearby pixels(including itself) in the input image, the kernel is that function 
	- the value(color, intensity, etc.) of a pixel in the output image depends not just on that pixel in the input image  but also on the pixels adjacent to it 