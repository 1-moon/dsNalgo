
The process of estimating values between known data points 

- vertex attributes(color, texture coords, normals etc..) 
	When rendering a 3D obj, each vertex can have various attributes.
	These attributes are defined at the vertices of the obj 

- Rasterization 
	During rasterization, 3D -> 2D 
		to do this, the rasterizer needs to determine the values of vertex attributes for all the pixels that make up the triangles formed by the vertices. 