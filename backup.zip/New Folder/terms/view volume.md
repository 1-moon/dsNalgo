![[Pasted image 20241024121237.png]]

Encompassing(surrounding) the area of the scene that the camera can see. 