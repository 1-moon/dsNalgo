Uniform Size 
	objs maintain **the same size no matter how far away** they are. 
	