
Container to store fragments generated via rendering pipeline in 2D memory areas 

![[Pasted image 20241028142801.png]]

- Standard buffers(color and depth buffers)
	Front and back color buffersare defined double buffering 
	
- Additional buffers(stencil buffers)
	In many cases, depth-stencil buffers are used together 
	![[Pasted image 20241028145942.png]]
The buffer is per pixel. 
Works on integer values, usually with a depth of one byte per pixel. 
The Z-buffer and stencil buffer often share the same area in the RAM.
Used to limit the area of rendering. 
Makes use of the strong connection between z-buffer and stencil buffer.
	e.g. stencil values can be automatically incresed/decreased for every pixel that fails or passes the depth test.  
The simple combination of depth test and stencil modeifiers 
	-> a vast number of effects possible suchas stencil shadow volumes, two-sided stencil
	
Frame buffers are defined by resolution and bit depth 
- bit depth : typically 8bpp, 24bpp and 32bpp
- similar to those of textures