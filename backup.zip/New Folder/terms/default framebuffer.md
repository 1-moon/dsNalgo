When using APIs like OpenGL or DirectX, the FB is a memory buffer that holds the color, depth, and stencil info for rendering a scene. 

- def;   Being automatically created by the windowing system when creating a window for app 
- usage; All rendering commands(e.g. draw shapes, apply textures) outputs on the screen(직접)
- process; 
	call render() without binding an FBO, you are usually rendering to this default FB. 
	*e.g.*  call `glClear` or draw objs without switching the FB context, the output will be visible. 

