- **C** **ST**andar**D** **I**nput and **O**utput 
- Same as stdio.h 

### Difference with `<stdio.h>`

- stdio.h use global namespace 
- cstdio use namespace called **std** 

### Difference with `<iostream>`
They are very similar though, iosream is better for safety issue 
	- Type-safe
		iostream allows the compiler to statically know the type of objs 
		cstdio uses `%` to determine the type dynamically  
	- Error 
		iostream does not use %  -> don't care eror from matching
		cstdio uses `%` token which can occur the format matching err 
	- Scalability 
		iostream can handle user-defined types for I/O 
	- Inheritance 
		iosream built from real cleass like `std::ostream` or `std::istream`, allowing for inheritance  -> users can define their own streams and make them functional 
