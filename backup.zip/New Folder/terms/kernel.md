
### Kernel in OS 
It acts as an intermediary between applications and the HW of the computer 
- Resource Management
- Process Management
- Memory Management 
- Device driver 
- System calls 

### Kernel in img processing 
a [[convolution matrix]], or mask 
	a small matirx used for blurring, [[sharpening]], [[embossing]], edge detection, and more. 

How to accomplish this mask ? 
	By doing a convolution between kernel and an img 