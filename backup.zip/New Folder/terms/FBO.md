Frame Buffer Objects in OpenGL 
off-screen FB 

def; User-defined FB, *i.e.* give me more ctrl over the rendering process. (reflection, shadowmap..)
usage; Output stored in textures or renderbuffer before displaying on the screen.
procss; 
	Subsequent rendering commands -> off-screen buffer
	After rendering, switch back to the default framebuffer. 

- render2texture pipeline 
- GPU img processing 
	setup OpenGL for image processing 


### RTT Pipeline 
Allows us to render a scene directly to textures instead of the default framebuffer, which is usally the screen. 
	instead of the [[default framebuffer]]....? 
	

- Simplified view 
	Create a FBO 
		Special OpenGL obj -> Act as an off-screen rendering target (no displaying). 
	Create texture & renderbuffer
		textures; one for color output of the rendering process. (2/3D or cubemaps etc..)
		renderbuffer;  one for depth and stencil 
	```cpp
	GLuint fbo, rbo, tex;
	glGenFramebuffers(1, &fbo);
	glBindFramebuffer(GL_FRAMEBUFFER, fbo);
	```
	Attach textures and Renderbuffer to the FBO 
		After creating the FBO, need to attach color textures and renderbuffer to it.
		By binding the FBO and specifying which texture/renderbuffer should be attached  
		==you can add more textures as color targets(e.g. upto 8 tex) at the same tile==
			GL_COLOR_ATTACHMENT1, 2, 3,....
			Multiple render targets(MRT)
			May lead to significant performance drops  
	```cpp
// Attach 2D texture to FBO 
glFramebufferTexture2D (GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex(colorTexture), 0 /*mipmp level*/)
 
// create renderbuffer 
glGenRenderbuffers(1, &rbo ); 
glBindRenderbuffer( GL_RENDERBUFFER, rbo); 
glRenderbufferStorage( GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, 256, 256 ); // 256x256
// attach the renderbuffer to FBO 
glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rbo );
	```
	Render a Scene (to the attached textures)
		Once the FBO is set up, 
		
	User the Output Textures as inputs to later shader pass 
