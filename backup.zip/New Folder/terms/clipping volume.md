![[Pasted image 20241024121305.png]]

The 3D space defined by the boundaries (planes) that determine what parts of objs will be rendered and whay parts will be discarded. 



