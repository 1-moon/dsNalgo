Image manipulation technique for making the outlines of a digital image look more distinct 

![[Pasted image 20241028140715.png]]

