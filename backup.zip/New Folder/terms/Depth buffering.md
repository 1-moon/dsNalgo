Z-test or Z-buffering 
Shortly, Maintains only nearest fragments in the buffer. 

[[depth]]..? 

A type of data buffer used in graphics to represent depth info of objs in 3D space. 
Stored as a height map of the scene
The values representing a distance to camera, with 0 being closest to camera 
An aid to rendering a scene to ensre that the correct polygons properly occlude other polygons  

- The most **common operation** in the raster graphics 
- Depth test on? **Comparion** between depths
	A fragment being created -> *compare* its depth *to* the existing depth in FB   
	```
	if my depth< the depth in FB 
		fragment visible // written to the color buffer with its depth 
	else  
		discard fragment  

	```
visible -> it's closer to the camera than what's already there 

Pros 
	to help maintain the correct visual order of objs in a 3D scene. 