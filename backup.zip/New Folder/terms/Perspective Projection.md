
Mimicing ->  how we naturally see the world 
	e.g. look at something far away, it looks smaller than sth close to you. 
	![[perspective-example.svg]]