
A **coordinate space** used during the rendering process 
- to determine which parts of a scene should be visible on the screen 
- the space after vertex transformation. 
