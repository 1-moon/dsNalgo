## Minmax_Mipmap 
What Min and Max in Mipmap stand for ...? 
- In rex, whenever increment the miplevel spinbox in index_min, black areas look bigger, while white areas look bigger in index_max. 
		**i.e.** min; select minimum value, max; select maximum value in range [0~1]
		(Filtering or selecting min/max value within texel in each miplevel)

main/reset()
- create `GMX` buffer with `vec4` size(4 floats);  `GMX` stands for Global Min-Max 
	- The usage of `gxCreateBuffer` looks quite similar with `glBufferData` 
		- target: `GL_UNIFORM_BUFFER`; this buffer will be used as `UBO` 
		- usage: `GL_STATIC_DRAW`; data modified once and used many times 
		- will be connected to layout uniform block(`GMX`) in shader 
main/assemble()
- `breakpoint`..?  How to use this unlike IDE's breakpoint ..?  
	- It seems to signal a specific point in this rex
		- `begin()`  :  stop at the start of a mipmap generation step..? 
		- `display`  :  stop at display phase for checking what we expected 

- `mipmap init` 
		Unlike texture func in previous mipmap, coords are manually set to avoid npot redundancy 
- `level-wise mipmap`; render `MMX` at each mip level
	-  Bind effect shader program with "build_mipmap" pixel shader for generation. 
		1) Binding process FBO <-> `MMX` at k level 
		2) Setting uniform variable `MMX` <- `MMX->view(k-1, 1)` 
		3) Generate mipmap within quad frame 
	- copy last mip to global minmax(`GMX`)  
		- How can `GMX`  be the buffer for writing..? (shader only read data in buffer) 
			- When binding to `SSBO`, named `SSMX`, enable `GMX` write
			- Why do we need last-mip to be written on buffer ? 
				- After searching min/max at last mip, we need to store them in buffer.
				- The last one serves as the summary of the texture in terms of color/intensity
	
- Bind FBO `without attachments`; 
	- nothing will be written to the color/depth buffers
	- (no need to render on our screen as `SSBO` is used for direct data storage)
- Bind effect with `copy_last_mip`  pixel shader   
	- copy 1x1 texture of `SRC` to `ssmx`
- Bind effect with buffer `ssmx` which is bound to `GMX`that contains last mip data.
	- Writing process of `SSMX` on `GMX` buffer  
- Set `SRC` uniform variable points to `MMX->lastmip`
	global min max query 
- Draw quad;  the last mip level data -> `GMX` 
	
- render output to DST;  changed the buffer binding to `GMX`
- read and validate `GMX` only at the first frame.(printed on terminal) 

pixel shader
- InitMipmap;  Create the resource for `buildMipmap` ....?  
	ts:  (w,h) of SRC at level 0 
	tc:  fragment's screen coords that scaled up by a factor of 2 via left bit-shift
	- Sampling a 2x2 block of texels surrounding the current texel at `tc` 
		t = tc + ivec2(0,0)~(1,1)  
	- Fetch the texel value with `texelFecth(SRC, t, 0).x`  
		Retrieve the intensity or luminance..? due to gray scale texture..? 	
	- Calculate min, max values of the grayscale intensity.  
	- `pout.y == 0` ..?
		- pout.x : minimum value, pout.y : maximum value 
		- Valid check, the mipmap sample is not generated 

- BuildMipmap; create mipmap at each level from the previous one. 
	- Extract the x and y components from the fectched texel (`MMX` at `tc`) 
		- Why is it taken as a `vec2` even though the texture is grayscale..? 
	
	- Also fetches texels from four neighboring positions by `texelFetchOffset`
		Unlike `initMipmap`, it operates on a mipmap (already downscaled texels form `MMX`) 
	- m.y > 0 ...? 
		- Seem to filter out invalid texels such like transparent texel ....  

- CopyLastMip;  Fetch the texel `SRC` being set to the last mip level of the `MMX`  
- Display; 
	- index_min; retrieve texels from `MMX` at coords for the current fragment.
	- index_max; same as above 
	- index_src  ; retrieve texels from `SRC` without interpolation
	- index_norm; fetch texel from SRC and then normalise them into [0~1]
### Transformation 

#### Gradient effect 
Gradual transition between two or more colors on mipmap 
- lerp formula 
$$ a\cdot(1-t) + b\cdot t$$
- How..? 
	- apply lerp on `INDEX_MIN` (replace `texture()` -> `texelFetch()` )
		1) texture coords -> texel coords and then `texelFetch` from `MMX` 
		2) nomalise between `gmx.x`(min) and `gmx.y`(max)
		3) use `mix()` with nomalised value for lerp
		4) output the mixed color with alpha=1.0 
![[Pasted image 20241112190126.png]]


## Holegen 
Hole generator for an image 

hole.h 
- `hole_t`;            A base struct contains pos and methods related to intersections.  
- `selected_t` ;    A struct inherits from `hole_t`, which means it has all the mems & methods.
main/update 
- `hole.pos.a`; Alpha value of `hole` 
	 is it zero? i.e. The `hole` will not appear in the output. -> escape from this function 
- Bind `FBO` with `DST`; FBO -> DST 
- Bind `effect` with `draw_hole`;   draw_hole shader program is bound. 
- `set_unigorm SRC`; convey `*pp_SRC` (texture source)-> uniform var valled "SRC"
- `set_uniform hole`; convey hole.pos.xyz(hole info)-> uniform var called "hole"  
- `draw_quads`; render rentangle hole within SRC texture quad  
-  `hole.pos.a = 0` ; hole.alpha init

main/on_mouse 
- `LBUTTONDOWN`; left mouse button pressed
	Hole intersect check with mouse cursor
	- If yes, allocate hole obj into selected obj using operator=(deep copy)
	- selected mouse pos  <- at mouse click 

- `LBUTTONUP`; left mouse button released 
	-  call `reset()` method; set `b_selected` into `false`  
- `MOUSEMOVE`; mouse move (drag the hole in any directions)
	How to implement that the hole follows the mouse as we drag ? 
	- `vec2 delta` ;  The variable for capturing a change from starting point to current pos
	- use `std::clamp()` for `delta + current hole pos` between hole's size   
	- update `hole pos` 
### Transformation 
#### circle hole 
- quad hole logic 
	- Check if the x and y offsets from the centre are both less than `hole.z`(size)
- circle hole logic 
	- Calculate the Euclidean distance(`length()`) from the fragment to the hole's centre. 
$$ \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}$$
	- Does the distance less than hole.z ..? then the fragment is considered to be inside. 
![[Pasted image 20241113120848.png]]



## Pull-Push-Synth
pull-push synth
	A technique where mipmap levels are used for both pull and push models 
pull(downasampling),  push(upsampling), synthsis(+) at mipmap..? 

- shader 
	- pad2pot 
		- Check the fragCoords are within the bounds of SRC, otherwise padding value, namely vec4(0), will be output.
	- pull;   downsampling 
		1) Bring offset of current fragment pixel
		2) Determine the valid range for texel at that specific mip level
		3) Fetch texel at each offset from `PULL` texture(previous level to generate current one) 
		4) Accumulate the rgb value if the texel's alpha larger than 0 
		5) Normalise 
		![[pull_mipmap.png]]
	- push;  upsampling 
		  1) Calculate the texel of the current fragment 
		  2) Convert current texture coords -> upper mipmap level by halving it 
		  3) 0 ? 1 : -1 
			Calculate the offset for the current coords, based on whether it's event or odd 
		  4) q = p + f  (By adding the offset, create a finer texture coord)   
		  5) Check; is it within valid bounds of the upper texture ? 
		  6) Collect smamples 
		  7) Sample the texture at the `q` and accumulate the RGB if alpha is greater than 0 
		  8) Normalise 
		![[Pasted image 20241113155324.png]]
	- crop2Npot
		After binding with `DST`
	
- main.cpp / render() 
	- if(!`b_npot`) statement executes when b_npot is false. 
		- Btw, `b_npot = false` stands for npot texture????? looks indicating pot..... ?!
		- padding to pot
			1) Target FBO into `PULL` texture for rendering 
			2) Set effect shader program to `pad2pot` (simply whether tc is outside of bound of the texture size)
			3) draw quad 
	
	- pull   phase;   
		- bind effect with `psPull` (similar with mipmap)  
		- For loop; why pot and npot get differently started ?  
			- pot; start at level 1 since level_0 is already in the required pot formt ..?
			- npot; otherwise, start at level 0 

			- Basically, similar with the general mipmap though, this downsampling handles both texture types(pot&npot) 
	- push phase;  
		- bind effect with `psPush` 
		- for loop in opposite direction from kn-2..? 
			- the last level doesn't have a next level to push into
			
			- Target FBO into `PUSH` texture for rendering 
			- Set `PULL`for the current miplevel
				- lower sampler; This will be used for upsampling resource                    
			- Set `PUSH` for the next mip level 
				- bind the upper level(data generated `PULL`)


### Transformation 
#### Reducing Color Precision Through round-down
- How..? 
	-  use rounding-down function on ouput with fewer color channels
	`pout.rgb = floor(pout.rgb * 63.5) / 63.5;` 
	
![[Pasted image 20241113183405.png]]
