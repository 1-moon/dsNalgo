## GUI 
### GLFrame 
- channel; filter a color on roaded image - Alpha(fully opaque, default -> 1 );  
- font;  font change 
- jetmap; low->blue, medium ->green/yellow, high -> red in color gradient 
- layer; layer index to display   
- miplevel; control blur level on image  
* .dynamic; variable  
### Render chain Pane 
- The order of the plugins are stored in an array. -> seems to be executed in the order of the index. (i.e. ==window-> project -> GL_Texture2D->GLFrame->OpenGL per each frame)==
## Main.cpp in common
- IRexDLL::metadata; 
	singleton = single instance False or multiple instances 
	enable_loop = update, render -> active or inactive   
	enable_mouse = mouse callback -> active or inactive 
	progressive = ture; update, render in PR -> active (gradually improving by update)
- release; deallocate 
	reverse order..?; dynamic deallocated in a heap so that it can avoid memory leaks 
-  Assemble; manage input/ouput for plugin framework.  
	- export_data; suggests that the 'p_texture' (a pointer to a texture) is being made 
	- import_data  indicates that 'pp_image' is being populated with data 
	- pointer/data callback - whenever `variable` changes, '`on_dirty_`'  are called
	- create_control ; create GUI control  
	
- initial_update
	- Create frame buffer; memory areas that stores fragments/pixels genetated via OpenGL pipeline 
	- Create effect 
		get_name; bring the name of plug-in image 
		`STR_TTGL_effectName_FX`;  which effect we are gonna call 
		
- update; Being called at every render frame, before rendering of all plugins 
	`tprintf()` ..? 
		Customised in rex.h  
		The msgs are displayed when setting Debug mode on the bottom of rex 
	1) Add invert control 
	2) Right-clicking -> clear/add hot key 
	3) Press `.` -> GLFrame toggle down/up 
- render; 
	FBO; Frame Buffer Obejct 
		1)set_state(false, false) -> Depth test, Cull Face, Blend, Wire Frame -> off 
		2)Bind with DST; FBO binds with `DST` texture for rendering 
		3)pp_SRC -> SRC;  allocate to new pointer var 
## .fx in common 
- interface PSIN
	interface; act like a struct in C++ (#define interface `__STRUCT__`)
	renamed PSIN, contains a `tax` 2D variable   
- uniform sampler2D
	uniform; constant data that applies globally to a shader program. 
	sampler2D; type qualifier used to define a texture sampler for 2D textures.   
- shader vsQuad; **Vertex shading** 
	`gl_position`;  sets the final position of the vertex after transformation.    
	`vout.tex`; passes the texture coords to fragment shader.
	- in: position, normal, and texcoord -> point's info
	- out: vec4 position in [[clip space]] 
- shader psInvert ; **Fragment shading** 
	`ivec2 tc`;  screen-to-texture coords  
		`ivec2()` ;  Fragment's coords -> **integer**  
	`pout`;  fetch a texel(`tc`) within a texture(`SRC`)  
- set shader version 440 


## Invert 
- Color invertion of an image 
	the lighter areas => dark && the dark areas => light 

### Invert.fx
- Sharder file for invert effect (GLSL base)
	`if(b_invert) pout.rgb = vec3(1) - pout.rgb`
		vec3(1) = vec3 (1.0, 1.0, 1.0) -> rgb 1.0 -> white   
		white - pout(our texture) => invert  
### Transformations 
#### Brightness
- Formula  
	R' = R + alpha 
	G' = G + alpha 
	B' = B + alpha 
- Shader file 
	if (b_invert) pout.rgb = pout.rgb + alpha; 
![[Pasted image 20241029115441.png]]
#### Solarization 
Partial invert effect - affecting only the bright parts of our texture using threshold 
- Formula 
$$
 \begin{aligned} R' &= \begin{cases} R & \text{if } R < T \\ 1 - R & \text{if } R \ge T \end{cases} \\[10pt]  G' &= \begin{cases} G & \text{if } G < T \\ 1 - G & \text{if } G \ge T \end{cases} \\[10pt]  B' &= \begin{cases} B & \text{if } B < T \\ 1 - B & \text{if } B \ge T \end{cases} \end{aligned}$$
- Shader file 
	float threshold = 0.5;
	float brightness = dot (pout.rgb, vec3(0.299, 0.587, 0.114))
	if (brightness > threshold && b_invert) pout.rgb = vec3(1) - pout.rgb;
	![[Pasted image 20241029131732.png]]
#### Gamma correction 
The process of adjusting the mid-tone brightness of  a texture 
- Formula 
	R' = R^gamma 
	G' = G^gamma 
	B' = B^gamma 
- Shader 
	pout.rgb = vec3(pow(pout.r, gamma), pow(pout.g, gamma), pow(pout.b, gamma))

![[Pasted image 20241029135818.png]]

## rgb2gray 
rgb-> gray within a texture 
### rgb2gray.fx 
- `ntsc` ; coefficient value for making gray color 
- `shader psrgb2gray`; fragment shading 
	- rgb2gray on -> dot product `ntsc` with my texel rgb for gray texture 
		- .dot().rrr...? 
			Swizzling in GLSL 
				.r -> first component
				.rrr -> repeat 3 times of first component  i.e. vec3(result, result, result) 

- Gray = (0.299 * R +0.587 * G + 0.114 * B)
### Transformations 

#### Flip 
- Horizontal Flip 
	x' = 1- x
	y' = y
- Vertical Flip 
	x' = x
	y' = 1 - y 
- Shader 
	vec2 tex_size = vec2(textureSize(SRC,0));  
	float newX = (1.0 - pin.tex.x) * tex_size.x ; newY = pin.tex.y * tex_size.y (vice versa)
	pout = textelFetch(SRC, ivec2(newX, newY), 0) 
![[Pasted image 20241029161241.png]]

