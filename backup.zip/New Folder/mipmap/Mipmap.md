Mipmap generation 


- render 
	Bind FBO(created in init_update) with `DST` as render target
	Init frame buffer bound to `DST` 

	Bind effect obj with 'copy' shader in .fx 
		non-pot(non power of 2) -> pot(power of 2) like 64x72 -> 64x64 
	load `SRC` on to effect obj
	quad render; generate copy input texture     

	Bind effect with `build_mipmap` shader in .fx 
	set uniform var `func` for how to sample texture 
		func == 0 ? textFetch : texture() -> what is difference ..? 
	for loop from 1 to the highest mip_levels(incremented by `on_dirty_src` call back) 
		whenever mip(0~7) changes, the `DST` is updated with the corresponding level. 
		set `MIP` uniform variable with a texture view of the k-1 level 
			min_level = k-1; since k starts at 1  
			quad renderl; generate downsampled texture. 
- shader 
	psCopy;  retrieves texels from `SRC` (literally, copy fragment shader)
	psBuildMipmap
		gl_FragCoord.xy << 1; bit shift for covering double size pixel block 
		for loop 0~3 ; generate mipmap level
			1)calcuate offset  2x2 block  (k>>1; divide by 2, k&1; remainder of division by 1)
				k = 0; offset (0,0)
				k = 1; offset (0,1)
				k = 2; offset (1,0)
				k = 3; offset (1,1)
			2) pixel sampling 
				func == 0; bring `tc+offset` texel via `texelFetch`
				func != 0;   bring `tcf+offset / ts` texel from `pin.tex` via `texture`
			3) sum up pixel color 
				`t.a > 0` ; only allowed alpha > 0, i.e. block  vacant color 
				accumulate color for output  
		Normalisation set alpha value 1  e.g. (0.5, 0.2, 0.7, 0.7) -> (0.5, 0.2, 0.7, 1.0)