minmax mipmap은 일반적인 minmap과 다르게
픽셀의 min/max 값을 저장하여 다른 용도로 활용되는 것임 
일반 mipmap
	- Usage: 게임이나 그래픽 엔진에서 원거리에 있는 객체나 텍스처에 대해, 불필요한 고해상도 텍스처 로딩을 피하고 최적의 렌더링 속도를 유지하기 위해 사용 
	- Goal: 해상도에 따른 최적의 texture 선택, 고해상도 texture를 필요로 하지 않는 원거리에서 resource를 절약하고 성능을 향상시킴.  
Minmax Mipmap
	- Usage:
		충돌감지; 특정 영역 내에서 객체가 충돌할 가능성이 있는지 효율적으로 판단 
		shadow map; shadow 영역의 명암 분석에서 최소값과 최대값을 사용해 적합한 shadow level을 계산 
		명암과 관련된 효과를 더욱 정확하게 적용 
		

minmax mipmap for minmax query and depth-map normalisation 

GMX; global  Min-Max 
max -> 1 white 
min -> 0 black 

safe_dete (GMX)
	GMX is null at first 
gxCreateBuffer;  create a buffer  (glBufferData)
	target; the target to which the buffer obj is bound   
		-> 	GL_UNIFORM_BUFFER; Uniform block storage 
	usage; the expected usage pattern of the data store 
	i.e. A hint to the GL implementation as to how a buffer obj's data store will be accessed. 
	(It enables the GL implementation to make more intelligent decisions that may significantly impact buffer obj performance.)
		->    GL_STATIC_DRAW;  The data store contents will be modified once and used many times as the source for GL drawing commands.  <-> GL_DYNAMIC_DRAW
=> nullptr 인 GMX에  GMX buffer를 만드는 것임 

glBufferData;  create a new data store for the buffer obj currently bound to target 
	- Any pre-existing data store is deleted 
	- The new data store is created with the speicifed size in bytes and usage 

set_pointer_callback 
	pp_SRC 가 변경될 떄 MMX 와 DST need to update  
		Once source texture changed, `MMX` & `DST` need to update (delete former one, recreate) 
	

GUI control
	index -> list box (SRC, Norm, Min, Max )
		SRC -> source texture 
		Norm -> Normalisation ? 
		Min -> minimise mipmap mode and Max -> maximise ...? 
		 

initial_update 
	init FBO 
	macro; generate macro at runtime i.e. Enable macro change the value dynamically. 
		`index_t::INDEX_SRC` -> `#define INDEX_SRC (integer)`
		 macros as constant will be used within the shader file. 
	 
render 
- `breakpoint`..?  How to use this unlike IDE's breakpoint ..?  
	seems to signal a specific point in this rex
	.begin(); stop at the start of a mipmap generation step..? 
- `mipmap init` 
	Unlike texture func in previous mipmap, coords are manually set to avoid npot redundancy 

- `level-wise mipmap`; render `MMX` at each mip level  

- copy last mip to global minmax  
	How can `GMX`  be the buffer for writing..? (shader only read data in buffer) 
		When binding to `SSBO`,  `SSBO` named `SSMX` enable `GMX` write
	- Bind FBO `without attachments`: nothing will be written to the color/depth buffers
		no need to render on our screen as `SSBO` is used for direct data storage
	- Bind effect with `copy_last_mip`  pixel shader   
		- copy 1x1 texture of `SRC` to `ssmx`
		- Why last mip texture ? 
			The last one serves as the summary of the texture in terms of color/intensity
	- Bind effect with  buffer `ssmx`which is bound to `GMX`that contains last mip data.
	- Set `SRC` uniform variable points to `MMX->lastmip`
		global min max query 
	- Draw quad;  the last mip level data -> `GMX` 

- render output to DST 

- read and validate global minmax only at the first frame. 