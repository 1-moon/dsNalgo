Hole generator for an image 

test
effect->bind("draw_hole") 
	err; no program is bound; search ends up with no associated program.
	아무것도 그려지지 않음. 
effect->set_unifrom("SRC", `*pp_SRC`) 만 지웠을 떄 검은색 화면 i.e. 원본파일이 사라짐 
effect->set_uniform("hole", `hole.pos.xyz`) 만 지웠을 떄 hole이 보이지 않음 
effect-> draw_quads() 를 지웠을때 검은 바탕화면만 나옴. i.e. render에 있어서 중심적인 역할 


set_data_callback (hole with on_dirty_hole) 
	register a callback function 
	`hole.pos.a` is modified -> trigger `on_dirty_hole()` -> hole.pos.a = 1.0f 
	 
main/update 
- `hole.pos.a`; (Valid check) Alpha value of `hole` 
	 is it zero? i.e. The `hole` will not appear in the output. -> escape from this function 
- Bind `FBO` with `DST`; FBO -> DST 
- Bind `effect` with `draw_hole`;   draw_hole shader program is bound. 
- `set_unigorm SRC`; convey `*pp_SRC` (texture source)-> uniform var valled "SRC"
- `set_uniform hole`; convey hole.pos.xyz(hole info)-> uniform var called "hole"  
- `draw_quads`; render rentangle hole within SRC texture quad  
-  `hole.pos.a = 0` ; hole.alpha init

main/on_mouse 
- `LBUTTONDOWN`; left mouse button pressed
	Hole intersect check with mouse cursor
	- If yes, allocate hole obj into selected obj using operator=(deep copy)
	- selected mouse pos  <- at mouse click 

- `LBUTTONUP`; left mouse button released 
	-  call `reset()` method; set `b_selected` into `false`  
- `MOUSEMOVE`; mouse move (drag the hole in any directions)
	How to implement that the hole follows the mouse as we drag ? 
	- `vec2 delta` ;  The variable for capturing a change from starting point to current pos
	- use `std::clamp()` for `delta + current hole pos` between hole's size   
	- update `hole pos` 
nx & ny      : normalised coords of the mouse cursor's position `[0~1]`
selected.m : the starting point of the mouse click when you first press down on the mouse 