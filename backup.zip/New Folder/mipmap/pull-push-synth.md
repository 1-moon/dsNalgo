pull-push synth ..? 
- pull model 
The consumer(downstream) requests data from the producer when needed. 
(The control is in the hands of the consumer, which pulls data as requried.
	 It aggregates and down-samples data from a higher-resolution texture 
		-> to fill in missing or empty areas in the lower-resolution mipmap levels. 
	"Pull" data from neighboring texels to compute new values as needed. 

- push model 
The producer(upstream) sends data to the consumer without being explicitly asked, effectively pushing data downstream as soon as it is available 
	- `psPush` shader 
	It takes the data synthesized during the pull phase
	"Pushes" it into higher-resolution mipmap levels to propagate the info upward.  

pull-push synth
	A technique where mipmap levels are used for both pull and push models 

psPull;  downsampling, same as buildMipmap 
psPush; upsampling 


current miplevel of pull texture  -> push texture 

- shader 
	- pad2pot 
		- Check the fragCoords are within the bounds of SRC, otherwise padding value, namely vec4(0), will be output.
	- pull;   downsampling 
		1) Bring offset of current fragment pixel
		2) Determine the valid range for texel at that specific mip level
		3) Fetch texel at each offset from `PULL` texture(previous level to generate current one) 
		4) Accumulate the rgb value if the texel's alpha larger than 0 
		5) Normalise 
		![[pull_mipmap.png]]
	- push;  upsampling 
		  1) Calculate the texel of the current fragment 
		  2) Convert current texture coords -> upper mipmap level by halving it 
		  3) 0 ? 1 : -1 
			Calculate the offset for the current coords, based on whether it's event or odd 
		  4) q = p + f  (By adding the offset, create a finer texture coord)   
		  5) Check; is it within valid bounds of the upper texture ? 
		  6) Collect smamples 
		  7) Sample the texture at the `q` and accumulate the RGB if alpha is greater than 0 
		  8) Normalise 
		![[Pasted image 20241113155324.png]]
	- crop2Npot
		After binding with `DST`
	
- main.cpp / render() 
	- if(!`b_npot`) statement executes when b_npot is false. 
		- Btw, `b_npot = false` stands for npot texture????? looks indicating pot..... ?!
		- padding to pot
			1) Target FBO into `PULL` texture for rendering 
			2) Set effect shader program to `pad2pot` (simply whether tc is outside of bound of the texture size)
			3) draw quad 
	
	- pull   phase;   
		- bind effect with `psPull` (similar with mipmap)  
		- For loop; why pot and npot get differently started ?  
			- pot; start at level 1 since level_0 is already in the required pot formt ..?
			- npot; otherwise, start at level 0 

			- Basically, similar with the general mipmap though, this downsampling handles both texture types(pot&npot) 
	- push phase;  
		- bind effect with `psPush` 
		- for loop in opposite direction from kn-2..? 
			- the last level doesn't have a next level to push into
			
			- Target FBO into `PUSH` texture for rendering 
			- Set `PULL`for the current miplevel
				- lower sampler; This will be used for upsampling resource                    
			- Set `PUSH` for the next mip level 
				- bind the upper level(data generated `PULL`)
