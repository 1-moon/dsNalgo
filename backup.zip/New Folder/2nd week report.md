
## BoxBlur 
 
Two-pass..?
A blur effect by separating it into two squential passes i.e. one for horizontal, one for vertical pass.  
- render in main.cpp 
	- blur -> off; No blurring effect is currently applied -> copying the `SRC` direcly to the `DST` 
	- blur -> on; 
		iterating twice in for-loop 
		- 1st pass; blur `SRC` into `TMP`  horizontally 
			dst ->TMP
			src -> SRC
			dir -> ivec2(1, 0)
		- 2nd pass; blur `TMP` into `DST` vertically
			dst -> DST
			src -> TMP
			dir -> ivec2(0,1)
		- Bind FBO with `dst` texture. 
		- Set the `src`, `dir` uniform variable in the shader program. 

- shader file  
	kernel_size...? 
	- psBoxBlur; calculate new texel for blur 
		For each loop iteration (-min64 ~ +max64) for computing the average of surrounding pixels 
			- 1st pass in x-axis; Valid sample(`tc`within `ts`?) are fetched  
			- 2nd pass in y-axis;  same as 1st pass, but in different direction  
			- sum; each sampled pixel color is added to (accumulation)  
		Calculate the average color (total sampled RGB values/ counts of samples)
### Transformation 
#### Single channel blur
- shader 
	- e.g. Green channel blur;
	    pout.r = texelFetch(SRC, tc0, 0).r;   
		pout.g = sum.g / sum.a; 
		pout.b = texelFetch(SRC, tc0, 0).b;
		pout.a = texelFetch(SRC, tc0, 0).a;
![[Pasted image 20241029180425.png]]
#### Gaussian blur 
- formula; 1D 
	![[Pasted image 20241031185409.png]]
- shader
	float weight = gaussian_weight(i, sigma); `i` is kernel_size  
	sum += texelFetch(SRC, tc, 0) * weight
![[Pasted image 20241031185352.png]]
## MLS 
Image Deformation by moving least squares 

- main.cpp 
	`on_mouse`; 
		- buttonDown; select the point
		- buttonUp; release the point 
		- mouseMove; deform the area that user selected in accordance with mouse dir  

- mls.fx 
	- `struct point_t`; struct for each control points including position, deform_on/off 
		pos ; a vertice position
		enable; Deformation on/off at that point 
		padding; 4 bytes dummy one in order for memory alignment as 16 bytes
	- `layout(std140, binding)`; UBO declare (encapsulate uniform variables as a buffer) 
		binding unit_1 - `CONTROL`;  control points  
		binding unit_2 - `DEFORMED`; deformed points 
	- vertex shader - `vsCircle`   
		Unlike `vsQuad` which just bypasses the vertex attributes... 
			calcuate the position coords  for circle  
	- fragment shader
		`fsColor`; assign a color of input texel  
		`fsCircle`; assign a color within a defined logic for a circular shape on the screen 
		`fsDeform`;  apply a deformation effect by using ctrl points 


## load-save 
Image handling for load/save 

- assemble() 
Set the ptr `p_image` with the callback function `on_dirty_image` 
	- Whenever `p_image` changes, createa a new texture and store it in `tmp`
`image_name` is also linked with a callback, `on_dirty_image_name`

- update()
 Image saving logic occurs at only first frame. (i.e. not all frames at all)
	 `SRC` -> `tmp` ; extract image data to `tmp` with finest mipmap level 
	 Configure the path of dir for saving image 
		 1) save as `tmp.png` at "caputure" folder  
		 2) save as `tmp.jpg` at plugin dir 
		 3) save as `tmp.jpg` at project data dir 

## Mipmap

Mipmap generation 

- render 
	- Bind FBO(created in init_update) with `DST` as render target
		Init frame buffer bound to `DST` 

	- Bind effect obj with 'copy' shader in .fx 
		non-pot(non power of 2) -> pot(power of 2) like 64x72 -> 64x64 
		load `SRC` on to effect obj
		quad render; generate copy input texture     

	- Bind effect with `build_mipmap` shader in .fx 
		set uniform var `func` for how to sample texture 
		- func == 0 ? textFetch : texture() -> what is difference ..? 
	- for loop from 1 to the highest mip_levels(incremented by `on_dirty_src` call back) 
		whenever mip changes, the `DST` is updated with the corresponding level. 
		set `MIP` uniform variable with a texture view of the k-1 level 
			- min_level = k-1; since k starts at 1  
			- quad render; generate downsampled texture. 
- shader 
	- psCopy;  retrieves texels from `SRC` (literally, copy fragment shader)
	- psBuildMipmap
		gl_FragCoord.xy << 1; bit shift for covering double size pixel block 
		for loop 0~3 ; generate mipmap level
			- 1)calcuate offset  2x2 block  (k>>1; divide by 2, k&1; remainder of division by 1)
				k = 0; offset (0,0)
				k = 1; offset (0,1)
				k = 2; offset (1,0)
				k = 3; offset (1,1)
			- 2) pixel sampling 
				func == 0; bring `tc+offset` texel via `texelFetch`
				func != 0;   bring `tcf+offset / ts` texel from `pin.tex` via `texture`
			- 3) sum up pixel color 
				`t.a > 0` ; only allowed alpha > 0, i.e. block  vacant color 
				accumulate color for output  
		Normalisation set alpha value 1  e.g. (0.5, 0.2, 0.7, 0.7) -> (0.5, 0.2, 0.7, 1.0)
### Transformation 
#### reverse downsampling 
- Former; down sampling from SRC to 1x1
- Latter; down sampling from 1x1 to SRC 

- main.cpp 
effect->set_uniform("SRC", DST->view(DST->mip_levels()-miplevel-1, 1));
![[revere_order.png]]
