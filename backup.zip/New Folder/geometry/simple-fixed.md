
simple fixed-pipeline emulation using OpenGL shaders 

Fixed pipeline vs programmable pipeline 
	In these days, there is no hardware fixed-functionality anymore . it's all shaders.
	With the release of OpenGL 3.3, all of the fixed-function API were removed.  
=> So, we imitate the behavior of fixed-pipline that shaders replaced instead? 

---- 
### GUI 
#### Camera 
- df;  focusing distance(in object distance) 
- F; focal distance (defult = 55mm)
- fovy; Adjust field of view vertically? (Field Of View Y axis..?) 
	- Angle between top boundary of the view volume and bottom boundary 
![[Pasted image 20241121164541.png]]
- control
	- first-person view; only allowed to view in sight of person(being tacked on the ground) 
	- trackball; camera view can move around anywhere 
- fnumber; Ratio of the focal length to the diameter of the aperture 
- history; track and manage the camera's state. 
	- Purpose 
		1) Keep track of changes in the camera's pos or orientation
		2) Determines whether the camera state needs to be updated 
		3) Use of `deque` ; store cam states in chronological order 
	- `History_CONT`; Always updates the state 
	- `History_DIRTY`; Update only when there is cam movement(b_dirty)
	- `History_FREEZE`; Allows manually freezing or restoring a specific state
- stereo; 
	- stereo rendering..? 
		- Rendering technique used to create 3D visualizations by simulating how human vision perceives depth. 
	- stereo_model {none, left, right, both, alter}; stereo-rendering model
		- None; no stereo rendering, a single 2D view 
		- Left; only the left-eye view is rendered. 
		- Right; only the right-eye view is rendered.
		- Both; both left and right-eye views are rendered simultaneously.(VR, 3D displays)
		- Alter; Alternates left and right-eye views for even/odd frames 
			- even frames render the left-eye view 
			- odd frames render the right-eye view    => these can be controlled by bitwise.  
	- ipd; inter-pupil distance; Between pupils.
#### TTGL_SimpleFixed 
- background ; tick on -> render background, tick off -> no render 

### Render chain 
light -> Camera -> Dynamics -> Mesh -> TTGL_SimpleFixed -> Frame 
- light - Camera - Dynamics 
	- Unlike direct calls to GPU like OpenGL, these plugins operate primarily on the CPU. 
	- Light; Configure lights 
	- Camera; Implement (trackball and first-person) view manipulators 
	- Dynamics; Dynamic transformation and structure changes to a mesh 
- Mesh; mesh plugin for creating and rendering vertex/index buffers 


### main 

release 
- FBO -> effect -> OUTPUT -> skydome(vertex array in BG) -> BG(Background cubemap) 
assemble 
- export  `OUTPUT`, where ps(`RGBZ`) is applied. 
- import plugin mesh, cam, light, and background data  
initial_update   < ------------------------------------------------------------- 해야함 


render
- FBO set_state
	- Depth-test, glEnable(GL_DEPTH_TEST)), on   
	- Cull-face, glEnable(GL_CULL_FACE), on 
- FBO's render target; `OUTPUT` texture. 
- FBO init rgb vec4(0.153f, 0.157f, 0.133f, 0) ...? How come...? 
- Render background 
- effect shader binds to vsFixed, psRGBZ. 
- Update camera(uniform struct) data on every single frame
- for loop on each geometry in mesh   
	- Does the cull operate? 
		- skip the current iteration and continues with next geometry. 
	-  `t` <- fetch a texture among material indices of mesh  
	- Forward uniform data to shader 
		- `g.ID` -> `DrawID`; which geometry are we gonna draw?
		- `t.albedo` -> `TEX`;  Fetch albedo data and forward to `TEX`
			- albedo; the base color of an object, before any lighting is applied. 
		- `t.normal` -> `NRM`;  Fetch normal data and forward to `NRM`
		- T/F -> `bTEX` ; bool texture, whether the above albedo texture exists or not 
		- T/F -> `bNRM`; bool normal,  whether the above normal texture exists or not 
	- Render all geometries stored in mesh (dino, skull, and dune)
		- How..? 
			1) Extract vertices from index buffer 
			2) Process rendering elements through vs -> ps 

### shader 

background  
- PSIN; Unlike previous 2D tutorials, pixel shader requires more data
	- `vec3 epos`; eye(camera) space pos 
	- `vec3 wpos`; world space pos 
	- `vec3 normal`; normal vector 
	- `vec2 tex`; UV coords for texture mapping  
	- `flat uint draw_id`; unique id for draw_call 
- `samplerCube`; BackGround CUBE map  
	- Backgrond texture mapping on cube 
- `uniform struct camera_t`; bring camera attributes for pixel shader  
- `uniform float bg_scale`; background scale as float type 

- vsSkydome
	- epos(view space); scale up every vertex and combine it with camera_view matrix  
	- gl_Position; vertex in clip space by Projection transformation  ![[Pasted image 20241122170036.png]]
	- vout.normal <- position.xzy; use normal for tex3. OpenGL cubemap uses DirectX left-hand 

- psSkyDome 
	- The potential fragment will be.... (r, g, b, depth) 
		- the RGB value sampled from the texture map based on `pin.normal` ![[Pasted image 20241122181047.png]]
		- Normalised fragment depth within range between the near plane and the far plane
			- around 0 -> close to cam which means opaque
			- around 1 -> far to cam which means transparent
			
simpleFixed 

- bbox; bounding box 
- light_t; 
- material;
- geometry; make  