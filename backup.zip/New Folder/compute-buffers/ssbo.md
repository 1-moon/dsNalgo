Shader Storage Buffer object(SSBO) 
- Simliar with UBO as uniform blocks 
- What differs from UBO..? 
	- Much larger 
		UBOs can be up to 16KB in size 
		SSBOs can be up to 128MB 
		(Most implementations will let us allocate a size up to the limit of GPU memory)
	- **Writable**
		- SSBOs reads and writes use incoherent memory access 
			- incoherent memory access 
				- not automatically visible to subsequent reads(need an explicit step)
					- e.g. memory barriers (make sure noticeable by later reads)
	- variable storage
		SSBOs have variable storage 
	- access 
		- slower than UBO access
			- SSBOs are generally accessed like buffer textures 
			- UBO data is accessed through internal shader-accessible memory reads 

---- 

main/assemble 
- create_control `atomic_sync` ; synchronisation of atomic operation in multi-threaded env.  
	- Atomic;  an operation that is performed as a single, indivisible action 
	- Atomic operations within SSBO for updating the histogram 
		- `atomicAdd`; atomic addition of _`data`_ to the contents of _`mem`_
		
-  create_control `compute_shader` 
	- A shader that is part of GPGPU(general purpose GPU)
		- It operates outside the graphic pipeline. 
		- Simply allow for GP computations that can be done in parallel on the GPU 
			- e.g. data manipulation. image processing, simulation etc.. 


main/render with ps&cs  
- Copy `SRC` to `DST`
	- `FBO` targets `DST` to be rendered
	- Bind effect shader program with `copy`
- Reset histogram 
	- Initialise SSBO named `HIST`  
- Save rgb color [0~255]
	- Is it compute shader ? -> Bind with `build_hist_cs` otherwise, `build_hist`
	- Forward uniform data(`SRC`, `atomic_sync`) to shader
	- Bind effect with initialised `HIST`
	- Is it compute shader ? -> dispatch compute groups (32, 32)
		- `glDispatchCompute`;  To execute a compute shader 
			- launch one or more compute work groups
			- 32 -> the number of local work groups 
			- (32, 32) -> these groups will be dispatched in X, Y dimensions, respectively. 
![[Pasted image 20241115193041.png]]
- Wait for completing SSBO in the previous pass 
	- used memory barrier due to "incoherent memory access" 
	- `GL_SHADER_STORAGE_BARRIER_BIT` ensures that the SSBO writings are completed. 
- Download 
	- image_data array declared
	- `get_sub_data`; get data from `HIST` buffer 
		- `glGetBufferSubData` ; return some of data from the BO bound to `HIST`
		- Copy it into the Image_data array 
- Find the range 
	- Search for the max value of `image_data` and update max_count in 3d respectively.
- Display images 
	- FBO targets `RED` ,`GREEN`, `BLUE` to be rendered 
	- Bind effect with `display` program 
	- Bind effect with `HIST` buffer
	- Forward uniform data (`max_count`, `resolution`)
- Logging 
	- tracking the rgb data to help with performace analysis on histogram 
		- accumulate the count of the rgb from the image-data container 

shader 
-  csBuildHist
	- `in(local_size_x=32, local_size_y=32)` ; 32x32 invocations per a workgroup
	- Look as follows![[Pasted image 20241116135234.png]]
	- ts <- `SRC` texture size at level 0 
	- tc <- `gl_GlobalInvocationID`; The index of the current invocation within the global space
		- `gl_GlobalInvocationID`; one of built-in compute shader inputs
			- `gl_WorkGroupID * gl_WorkGroupSize + gl_LocalInvocationID` 
				- `gl_wordGroupID`; The current work group for this shader invocation.
				- `gl_WorkGroupSize`; The size of a work group in a compute shader
				- `gl_LocalInvocation`; The current invocation within the work group. 
	- value <- extract rgb at `tc` within `SRC`
	- index <- convert `value` to [0~255] integer 
	- histogram count update 
		- atomic_sync on
			- Without the race condition where multiple threads access the same memory, atomic counter operates by 1 step on rgb indices 
		- atomic_sync off 
			- no atomic counting, just accumulate rgb by 1 step
- psBuildHist 
	- Similar with `csBuildHist` but there are some different points 
		- The texture coords(`pin.tex`) are typically interpolated from the vertices 
		- run as part of the graphic pipeline (influenced by state like blending. i.e. on-screen) 
- psDisplay
	- For loop RGB 
		- Scale each channel up multiplying it by 1.2  
		- Calculate a new `tc` for histogram
			- `y` coord is scaled by channel_scale normalised to the resolution's height
		- bound check; the `tc.y` within histogram
	- Display R, G, B of histogram  

### Transformation 
#### Combined histogram
![[Pasted image 20241120161611.png]]