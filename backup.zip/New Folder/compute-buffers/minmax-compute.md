compute-based ..? ; The use of compute shaders 
Parallel reduction for minmax..? 
- Serves as a great optimization
	- How..?
		- Tree-based apporach 
			- Structured as a reduction tree, in which the compute is divided into smaller
			- Each node in the tree represent a thread & performs part of the calculation 
			- combines the results in parallel to get the final min or max value ..? 
![[Pasted image 20241114165935.png]]

=>implementation of parallel reduction using a compute shader for finding the min and max values from a dataset. 

each compute shader instance searches fro local min and max from allocated data 
search for globl min and max by combining local min and max parallel 

----- 

main/initial_update 
- Create FBO
- Define preprocessor directive for WORK_GROUP_SIZE
- Create effect shader instance with `MINMAX_FX` file.  
	- Init the fx file with the given input param(`WORK_GROUP_SIZE` = 1024)
- Verify workgroup size (whether group size 1024 arranged like a 1D array)

main/render 
- Bind `effect` with `reduce_minmax` in `MINMAX_FX` file 
- Bind effect with ssbo named `MMX`
- Forward SRC texture info -> `uniform SRC` in shader file   
- Parallel Reduction loop
	 - As this loop iterates, the num of pixels goes down. -> The input texture shrinks  
	 - Flow
		- Foward the num of count(pixels) and k_miplevel to shader
		- `dispatchComputeThreads`; Create workgroups contain threads as much as count
		- `glMemoryBarrier`; used memory barrier due to "incoherent memory access" 
		- Check valid minmax in global as well as local 

shader
- csReduceMinmax 
	- `in(local_size_x=1204, y = 1)`; allocate 1024 invocations per workgroup
	- `tid` and `gid` ![[Pasted image 20241116183903.png]]
	- clear or read to shared memory 
		>`shared` keyword; shared variable 
			- Global variables in cs -> declared with the shared storage qualifier 
			- Being shared between all invocations within a workgroup 
			- no opaque type as shared e.g. sampler or image (Idk its internal structure)
		
		- Clear shared memory by allocating `NOPIXEL`
		1) Read input data directly from texture(level_0)     
			- the use of `texel_fetch` function 
				- `gid%ts.x` , `gid/ts.x` ; 1D index -> 2D texture coords
		2) Read minmax from `MMX` (level >0) 
			- read minmax from `MMX` in where the data has been calculated previously  
		3) Parallel reduction 
			- Keep halving the num of workgroups   
				- `minmax(sdata[tid],sdata[tid+s])`; compare (current thread, sister thread) 
			- write the minmax of current block to global memory
				- `MMX`<- `sdata[0]` (minmax data at first thread on each workgroup)
					`gl_WorkGroupID.x`  -> .x component  due to 1D array 
					`MMX.xy` -> x and y component due to MMX is defined vec4
					`sdata[].y` -> y component for indicating offsets on 1D array  

 Debugging 
- parellel reduction step only ran three times across this whole texture 
	1) mmx[0]=(0.121569 0.125490), threads=2073600, groups=2025
	2) mmx[0]=(0.047059 0.270588), threads=2025, groups=2
	3) mmx[0]=(0.047059 1.000000), threads=2, groups=1

