Mipmap generation with min/max on every four texels 

N-buffer         
- Mechanism with mipmap  
	- LV_0; The input texture data, where each texel represents data for a single pixel. 
	- LV_1; Compressed by storing the minmax of 2x2 bolcks from LV0, covering a radius of $2^1$.
	- LV_2; Compressed again by 4x4 pixel blocks from LV1, covering a radius of $2^2$
	- ......
	- LV_10; compressed lastly by 1024x1024 pixels block from LV10, covering a radius of $2^{10}$
	>Mipmap levels progressively compress texture data by storing the minmax values of pixel blocks, with each level covering a radius of $2^N$ pixels, where N is the mipmap level


Y-map-buffer   (min,max) at RG channel
	 2 level mipmap + n_buffer 


----
main/init_update 
- define preprocessor directive `NBF_USE_QUATER` and `YBF_USE_QUATER`
	- `#define NBF_USE_QUATER  nbuffer_t::NBF_USE_QUATER`
		- `fx::nbuffer2d_t<11,2,0>`; 11: miplevels, 2: RG, 0: full resolution 
	- `#define YBF_USE_QUATER  ybuffer_t::NBF_USE_QUATER`
		- `fx::nbuffer2d_t<11,2,1>`; 11: miplevels, 2: RG, 1: quater-area downsampling
main/render 
1) Setup FBO
	- set all states as false
	- clear data on FBO 
2) Initialise N-Buffers and Y-Buffers 
	- FBO's render targets : `nbuffer.texture` and `ybuffer.texture` 
	- Clear FBO's color buffer using `clear_color_buffer` instead `clear()` 
		- clear() is for more comprehensive function 
	- Call `init_buffers` shader program 
	- Forward SRC uniform value to shader 
	- Trigger the actual rendering process to FBO by `draw_quads()`

3) Build nbuffers 
	 - `build()` method 
		 1) Downsample the first layer
		 2) Build N-buffer layers
4) Find global minmax and write to the unifrom buffer in main effect 
	- Search for the global minmax across N or Y buffers. 
	- Write to `GMM` uniform buffer. 
5) Debugging by printing out the value in `GMM` 
6) Query N_Buffers
	- FBO's render target: `DST`  
	- b_ymap? bind effect with `ybuffer` shader otherwise `nbuffer`
shader 
- `psInitBuffers` 
	- Fetch intensity value(saved in .rgb uniformly) from grayscale `SRC`
	- why vec2 type  ..? 
		- we defined `NBF` and `YBF` in RG channels i.e. vec2(red, green)
		- `pout[0]`: left lower image on rex, representing initialised N-buffer 
		- `pout[1]`: right lower image on rex, representing initialised Y-buffer
	- 1-gray and gray ? 
		- 1-gray : min(?) color-inverted grayscale  , gray : max(?) grayscale color   
	- vec2(1-gray, gray)
		- visualise min as red,  max(?) as green 

- QueryNBuffer  
	- vec2 `minmax` <-  query nbuffer with pixel block range(query_size)
	- query_nbuffer 
		- query block less than 1?; Fetch texel from texture directly 
		- use quater size(1/4 resolution) ?
			- halve the texel coords and sample blocks![[Pasted image 20241119165849.png]]
		-  Not ? texture sampling without lower resolution 
			- compute tex1 and tex4 by layer index and offset
			- sampling tex2 and tex3 from tex4.x and tex4.y 
			- Max among the four texes 

### Transformation 
#### 1/16 resolution 
![[Pasted image 20241120175737.png]]
![[Pasted image 20241120180922.png]]

