Parallel Reduction 

- Easy to implement in CUDA 
	- But harder to get it right  :( 
- Serves as a great optimization example 

### Tree-based approach 
- Used within each thread block 
	-> Each thread block has its own reduction tree 
	
- Need to be able to use multiple thread blocks 
	- Need to process very large arrays 
	- Need to keep all multiprocessors on the GPU busy 
	- Each thread block reduces a portion of the array. 
	- 