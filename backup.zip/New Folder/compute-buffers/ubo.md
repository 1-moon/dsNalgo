An example for using Unifrom Buffer Objects 

a set of global unifrom variables 
	that remain the same over any number of shader program.

UBO.SPH                  green and orange interpolation 
UBO.SPH_X               red and vacant 
UBO.SPH_XXX           white and vacant 
UBO.SPH_Y               mono_green 


----

release 
FBO -> effect -> SPHs (textures) -> VAO
- VAO;  vertex array object,  
	- why we need..? 
			VBO에 담겨있는 정보 형식이 정해지지 않음, VBO 만 가지고는 해석하기 힘듬 
			VBO(vertex pos, color, texture, normal etc...)
>Global setup
>create VBO -> create VAO -> create a shader program -> draw 


main/init_update 
- Right after creating FBO, VAO will be created for SPHs using predefined sphere info 

main/update
Update model pos, rotation, scale based on time  
- `theta`;   A rotation angle based on time(this will be increased as time goes by )
- `aspect`;  The aspec ratio of the rendering surface 
- `model_matrix`;   A transformation matrix..? 
	- How the sphere is positioned, roated and scaled by `rotate() * scale()`
- `view_projection_matrix`; act like a camera  
	- Combine view and projection transforms to set up the camera

main/render 
- Buffer 
	- Bind shader program 'effect' with UBOs `MODEL`(matrix info) and `SPHERE`(sphere info) 
- Render order 
	- FBO - turn on depth test(which pixel more closer?) and cull face (cull behind scene)
	- FBO's render targets : SPHs
	- init FBO 
	- Bind shader program with fragment shader `draw_sphere`
	- render sphere based on the indices stored in `VAO`
		- 0 <- first offset among indices 
	
shader 
- Uniform block sphere and model 
	- `layout(std140)`; one of memory layout qualifiers for UBO 
		- no need to query the offsets when arranging data 
	- `binding =0 or =1` ; binding slot number  
		- It determines which resource is connected to the corresponding binding during execution 
	- row_major?
		- matrix storage order in row-major 

- vs
	- wpos;      world space position 
		- Scale each vertex by the predefined radius and then apply the model matrix to it
	- wpos.xy;  Adjust sphere position properly. 
	- gl_Position;  worldspace -> 2D screen by multiply projection matrix to wpos 

- ps
	- `pout[0]`;  R: pin.tex.x G: pin.tex.y  -> SPH 
	- `pout[1]`:  R: pin.tex.x                    -> SPH_X 
	- `pout[2]`:  G: pin.tex.y                    -> SPH_Y  
	- `pout[3]`:  RGB: pin.tex.x                -> SPH_XXX 

### Transformation 
#### Translation Animation 
- Add an another animation on `model_matrix` in which rotate and scale animations applied 
![[Pasted image 20241120144439.png]]
