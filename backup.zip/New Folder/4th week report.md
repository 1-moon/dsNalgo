## UBO 
An example for using Unifrom Buffer Objects 

a set of global unifrom variables 
	that remain the same over any number of shader program.

UBO.SPH                  green and orange interpolation 
UBO.SPH_X               red and vacant 
UBO.SPH_XXX           white and vacant 
UBO.SPH_Y               mono_green 


----

release 
FBO -> effect -> SPHs (textures) -> VAO
- VAO;  vertex array object,  
	- why we need..? 
		- The format of the information stored in the VBO is not defined, making it difficult to interpret using only the VBO
		- VBO(vertex pos, color, texture, normal etc...)
>Global setup
>create VBO -> create VAO -> create a shader program -> draw 


main/init_update 
- Right after creating FBO, VAO will be created for SPHs using predefined sphere info 

main/update
Update model pos, rotation, scale based on time  
- `theta`;   A rotation angle based on time(this will be increased as time goes by )
- `aspect`;  The aspec ratio of the rendering surface 
- `model_matrix`;   A transformation matrix..? 
	- How the sphere is positioned, roated and scaled by `rotate() * scale()`
- `view_projection_matrix`; act like a camera  
	- Combine view and projection transforms to set up the camera

main/render 
- Buffer 
	- Bind shader program 'effect' with UBOs `MODEL`(matrix info) and `SPHERE`(sphere info) 
- Render order 
	- FBO - turn on depth test(which pixel more closer?) and cull face (cull behind scene)
	- FBO's render targets : SPHs
	- init FBO 
	- Bind shader program with fragment shader `draw_sphere`
	- render sphere based on the indices stored in `VAO`
		- 0 <- first offset among indices 
	
shader 
- Uniform block sphere and model 
	- `layout(std140)`; one of memory layout qualifiers for UBO 
		- no need to query the offsets when arranging data 
	- `binding =0 or =1` ; binding slot number  
		- It determines which resource is connected to the corresponding binding during execution 
	- row_major?
		- matrix storage order in row-major 

- vs
	- wpos;      world space position 
		- Scale each vertex by the predefined radius and then apply the model matrix to it
	- wpos.xy;  Adjust sphere position properly. 
	- gl_Position;  worldspace -> 2D screen by multiply projection matrix to wpos 

- ps
	- `pout[0]`;  R: pin.tex.x G: pin.tex.y  -> SPH 
	- `pout[1]`:  R: pin.tex.x                    -> SPH_X 
	- `pout[2]`:  G: pin.tex.y                    -> SPH_Y  
	- `pout[3]`:  RGB: pin.tex.x                -> SPH_XXX 

### Transformation 
#### Translation Animation 
- Add an another animation on `model_matrix` in which rotate and scale animations applied 
![[Pasted image 20241120144439.png]]


## SSBO
Shader Storage Buffer object(SSBO) 
- Simliar with UBO as uniform blocks 
- What differs from UBO..? 
	- Much larger 
		UBOs can be up to 16KB in size 
		SSBOs can be up to 128MB 
		(Most implementations will let us allocate a size up to the limit of GPU memory)
	- **Writable**
		- SSBOs reads and writes use incoherent memory access 
			- incoherent memory access 
				- not automatically visible to subsequent reads(need an explicit step)
					- e.g. memory barriers (make sure noticeable by later reads)
	- variable storage
		SSBOs have variable storage 
	- access 
		- slower than UBO access
			- SSBOs are generally accessed like buffer textures 
			- UBO data is accessed through internal shader-accessible memory reads 

---- 

main/assemble 
- create_control `atomic_sync` ; synchronisation of atomic operation in multi-threaded env.  
	- Atomic;  an operation that is performed as a single, indivisible action 
	- Atomic operations within SSBO for updating the histogram 
		- `atomicAdd`; atomic addition of _`data`_ to the contents of _`mem`_
		
-  create_control `compute_shader` 
	- A shader that is part of GPGPU(general purpose GPU)
		- It operates outside the graphic pipeline. 
		- Simply allow for GP computations that can be done in parallel on the GPU 
			- e.g. data manipulation. image processing, simulation etc.. 


main/render with ps&cs  
- Copy `SRC` to `DST`
	- `FBO` targets `DST` to be rendered
	- Bind effect shader program with `copy`
- Reset histogram 
	- Initialise SSBO named `HIST`  
- Save rgb color [0~255]
	- Is it compute shader ? -> Bind with `build_hist_cs` otherwise, `build_hist`
	- Forward uniform data(`SRC`, `atomic_sync`) to shader
	- Bind effect with initialised `HIST`
	- Is it compute shader ? -> dispatch compute groups (32, 32)
		- `glDispatchCompute`;  To execute a compute shader 
			- launch one or more compute work groups
			- 32 -> the number of local work groups 
			- (32, 32) -> these groups will be dispatched in X, Y dimensions, respectively. 
![[Pasted image 20241115193041.png]]
- Wait for completing SSBO in the previous pass 
	- used memory barrier due to "incoherent memory access" 
	- `GL_SHADER_STORAGE_BARRIER_BIT` ensures that the SSBO writings are completed. 
- Download 
	- image_data array declared
	- `get_sub_data`; get data from `HIST` buffer 
		- `glGetBufferSubData` ; return some of data from the BO bound to `HIST`
		- Copy it into the Image_data array 
- Find the range 
	- Search for the max value of `image_data` and update max_count in 3d respectively.
- Display images 
	- FBO targets `RED` ,`GREEN`, `BLUE` to be rendered 
	- Bind effect with `display` program 
	- Bind effect with `HIST` buffer
	- Forward uniform data (`max_count`, `resolution`)
- Logging 
	- tracking the rgb data to help with performace analysis on histogram 
		- accumulate the count of the rgb from the image-data container 

shader 
-  csBuildHist
	- `in(local_size_x=32, local_size_y=32)` ; 32x32 invocations per a workgroup
	- Look as follows![[Pasted image 20241116135234.png]]
	- ts <- `SRC` texture size at level 0 
	- tc <- `gl_GlobalInvocationID`; The index of the current invocation within the global space
		- `gl_GlobalInvocationID`; one of built-in compute shader inputs
			- `gl_WorkGroupID * gl_WorkGroupSize + gl_LocalInvocationID` 
				- `gl_wordGroupID`; The current work group for this shader invocation.
				- `gl_WorkGroupSize`; The size of a work group in a compute shader
				- `gl_LocalInvocation`; The current invocation within the work group. 
	- value <- extract rgb at `tc` within `SRC`
	- index <- convert `value` to [0~255] integer 
	- histogram count update 
		- atomic_sync on
			- Without the race condition where multiple threads access the same memory, atomic counter operates by 1 step on rgb indices 
		- atomic_sync off 
			- no atomic counting, just accumulate rgb by 1 step
- psBuildHist 
	- Similar with `csBuildHist` but there are some different points 
		- The texture coords(`pin.tex`) are typically interpolated from the vertices 
		- run as part of the graphic pipeline (influenced by state like blending. i.e. on-screen) 
- psDisplay
	- For loop RGB 
		- Scale each channel up multiplying it by 1.2  
		- Calculate a new `tc` for histogram
			- `y` coord is scaled by channel_scale normalised to the resolution's height
		- bound check; the `tc.y` within histogram
	- Display R, G, B of histogram  

### Transformation 
#### Combined histogram
![[Pasted image 20241120161611.png]]

## minmax-compute
compute-based ..? ; The use of compute shaders 
Parallel reduction for minmax..? 
- Serves as a great optimization
	- How..?
		- Tree-based apporach 
			- Structured as a reduction tree, in which the compute is divided into smaller
			- Each node in the tree represent a thread & performs part of the calculation 
			- combines the results in parallel to get the final min or max value ..? 
![[Pasted image 20241114165935.png]]

=>implementation of parallel reduction using a compute shader for finding the min and max values from a dataset. 

each compute shader instance searches fro local min and max from allocated data 
search for globl min and max by combining local min and max parallel 

----- 

main/initial_update 
- Create FBO
- Define preprocessor directive for WORK_GROUP_SIZE
- Create effect shader instance with `MINMAX_FX` file.  
	- Init the fx file with the given input param(`WORK_GROUP_SIZE` = 1024)
- Verify workgroup size (whether group size 1024 arranged like a 1D array)

main/render 
- Bind `effect` with `reduce_minmax` in `MINMAX_FX` file 
- Bind effect with ssbo named `MMX`
- Forward SRC texture info -> `uniform SRC` in shader file   
- Parallel Reduction loop
	 - As this loop iterates, the num of pixels goes down. -> The input texture shrinks  
	 - Flow
		- Foward the num of count(pixels) and k_miplevel to shader
		- `dispatchComputeThreads`; Create workgroups contain threads as much as count
		- `glMemoryBarrier`; used memory barrier due to "incoherent memory access" 
		- Check valid minmax in global as well as local 

shader
- csReduceMinmax 
	- `in(local_size_x=1204, y = 1)`; allocate 1024 invocations per workgroup
	- `tid` and `gid` ![[Pasted image 20241116183903.png]]
	- clear or read to shared memory 
		>`shared` keyword; shared variable 
			- Global variables in cs -> declared with the shared storage qualifier 
			- Being shared between all invocations within a workgroup 
			- no opaque type as shared e.g. sampler or image (Idk its internal structure)
		
		- Clear shared memory by allocating `NOPIXEL`
		1) Read input data directly from texture(level_0)     
			- the use of `texel_fetch` function 
				- `gid%ts.x` , `gid/ts.x` ; 1D index -> 2D texture coords
		2) Read minmax from `MMX` (level >0) 
			- read minmax from `MMX` in where the data has been calculated previously  
		3) Parallel reduction 
			- Keep halving the num of workgroups   
				- `minmax(sdata[tid],sdata[tid+s])`; compare (current thread, sister thread) 
			- write the minmax of current block to global memory
				- `MMX`<- `sdata[0]` (minmax data at first thread on each workgroup)
					`gl_WorkGroupID.x`  -> .x component  due to 1D array 
					`MMX.xy` -> x and y component due to MMX is defined vec4
					`sdata[].y` -> y component for indicating offsets on 1D array  

 Debugging 
- parellel reduction step only ran three times across this whole texture 
	1) mmx[0]=(0.121569 0.125490), threads=2073600, groups=2025
	2) mmx[0]=(0.047059 0.270588), threads=2025, groups=2
	3) mmx[0]=(0.047059 1.000000), threads=2, groups=1


## Nbuffers
Mipmap generation with min/max on every four texels 

N-buffer         
- Mechanism with mipmap  
	- LV_0; The input texture data, where each texel represents data for a single pixel. 
	- LV_1; Compressed by storing the minmax of 2x2 bolcks from LV0, covering a radius of $2^1$.
	- LV_2; Compressed again by 4x4 pixel blocks from LV1, covering a radius of $2^2$
	- ......
	- LV_10; compressed lastly by 1024x1024 pixels block from LV10, covering a radius of $2^{10}$
	>Mipmap levels progressively compress texture data by storing the minmax values of pixel blocks, with each level covering a radius of $2^N$ pixels, where N is the mipmap level


Y-map-buffer   (min,max) at RG channel
	 2 level mipmap + n_buffer 


----
main/init_update 
- define preprocessor directive `NBF_USE_QUATER` and `YBF_USE_QUATER`
	- `#define NBF_USE_QUATER  nbuffer_t::NBF_USE_QUATER`
		- `fx::nbuffer2d_t<11,2,0>`; 11: miplevels, 2: RG, 0: full resolution 
	- `#define YBF_USE_QUATER  ybuffer_t::NBF_USE_QUATER`
		- `fx::nbuffer2d_t<11,2,1>`; 11: miplevels, 2: RG, 1: quater-area downsampling
main/render 
1) Setup FBO
	- set all states as false
	- clear data on FBO 
2) Initialise N-Buffers and Y-Buffers 
	- FBO's render targets : `nbuffer.texture` and `ybuffer.texture` 
	- Clear FBO's color buffer using `clear_color_buffer` instead `clear()` 
		- clear() is for more comprehensive function 
	- Call `init_buffers` shader program 
	- Forward SRC uniform value to shader 
	- Trigger the actual rendering process to FBO by `draw_quads()`

3) Build nbuffers 
	 - `build()` method 
		 1) Downsample the first layer
		 2) Build N-buffer layers
4) Find global minmax and write to the unifrom buffer in main effect 
	- Search for the global minmax across N or Y buffers. 
	- Write to `GMM` uniform buffer. 
5) Debugging by printing out the value in `GMM` 
6) Query N_Buffers
	- FBO's render target: `DST`  
	- b_ymap? bind effect with `ybuffer` shader otherwise `nbuffer`
shader 
- `psInitBuffers` 
	- Fetch intensity value(saved in .rgb uniformly) from grayscale `SRC`
	- why vec2 type  ..? 
		- we defined `NBF` and `YBF` in RG channels i.e. vec2(red, green)
		- `pout[0]`: left lower image on rex, representing initialised N-buffer 
		- `pout[1]`: right lower image on rex, representing initialised Y-buffer
	- 1-gray and gray ? 
		- 1-gray : min(?) color-inverted grayscale  , gray : max(?) grayscale color   
	- vec2(1-gray, gray)
		- visualise min as red,  max(?) as green 

- QueryNBuffer  
	- vec2 `minmax` <-  query nbuffer with pixel block range(query_size)
	- query_nbuffer 
		- query block less than 1?; Fetch texel from texture directly 
		- use quater size(1/4 resolution) ?
			- halve the texel coords and sample blocks![[Pasted image 20241119165849.png]]
		-  Not ? texture sampling without lower resolution 
			- compute tex1 and tex4 by layer index and offset
			- sampling tex2 and tex3 from tex4.x and tex4.y 
			- Max among the four texes 

### Transformation 
#### 1/16 resolution 
![[Pasted image 20241120175737.png]]
![[Pasted image 20241120180922.png]]

